"""Simulate the stochastic wm_2 response to a single dynamic-price step."""

from itertools import product
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from src.model.wm_2 import wm_2
from src.exe.tool.input_builder import input_builder

# Configure the time grid.
days = 10
t_interval = (0.0, float(days))
t_steps = 24 * days + 1
t = np.linspace(t_interval[0], t_interval[1], t_steps)
hours = 24.0 * t

inputs = input_builder()

# Keep synthetic baselines constant so the response isolates the price step.
B_O_level = 0.30
B_I_level = 0.30
PE_level = 0.50
B_O = inputs.energy((np.array([0.0, days]), np.array([B_O_level, B_O_level])))
B_I = inputs.energy((np.array([0.0, days]), np.array([B_I_level, B_I_level])))
PE = inputs.price((np.array([0.0, days]), np.array([PE_level, PE_level])))

# Build the dynamic-price step.
price_before = 0.75
price_after = 0.25
price_step_hour = 24.0
price_step_time = price_step_hour / 24.0
U = inputs.price((np.array([0.0, price_step_time, days]), np.array([price_before, price_after, price_after]),))

# Configure simplex coefficients and stochastic parameters.
alpha = np.array([0, 0.1, 0.1, 0.8])
beta = np.array([0.1, 0.85, 0.05])
gamma = np.array([0.25, 0.25, 0.25, 0.25])

kappa_R = 0.5
sigma_0 = 0.1
sigma_O = 0.4

parameters = {"U": U, "B_O": B_O, "B_I": B_I, "PE": PE, "alpha": alpha, "beta": beta, "gamma": gamma, "kappa_R": kappa_R, "sigma_0": sigma_0, "sigma_O": sigma_O,}

model = wm_2(t_interval, t_steps)

# Initialize at the pre-step expected equilibrium.
V0 = model.expected_equilibrium(B_O_level, B_I_level, price_before, alpha, beta)
R0 = 0.0
init_cond = [V0, R0]

# Use numerical truncation bounds; V = 0 and V = 1 are not pathwise boundaries.
v_bounds = (-0.2, 1.5)
r_bounds = (-1, 1)
v_steps = 101
r_steps = 101
cfl = 0.80

# Build a non-Gaussian product-Beta mixture around the deterministic initial state.
mixture_weights = np.array([0.25, 0.50, 0.25])

v_density_range = (0.0, 1.0)
v_component_means = np.array([init_cond[0] - 0.10, init_cond[0], init_cond[0] + 0.10])
if np.any((v_component_means <= 0.0) | (v_component_means >= 1.0)):
    raise ValueError("Chosen wm_2 beta-mixture V component means must lie in (0, 1).")
v_concentration = 80.0
v_shapes = np.column_stack((v_concentration * v_component_means, v_concentration * (1.0 - v_component_means),))

r_density_range = (-0.15, 0.15)
r_component_means = np.array([-0.025, 0.0, 0.025])
r_unit_means = ((r_component_means - r_density_range[0]) / (r_density_range[1] - r_density_range[0]))
r_concentration = 100.0
r_shapes = np.column_stack((r_concentration * r_unit_means, r_concentration * (1.0 - r_unit_means),))

initial_density = inputs.initial_density("beta_mixture", v_range=v_density_range, r_range=r_density_range, v_shapes=v_shapes, r_shapes=r_shapes, weights=mixture_weights,)

# Solve deterministic and Fokker-Planck dynamics.
deterministic = model.deterministic_solver(init_cond, parameters)
fp = model.fokker_planc_solver(init_cond=init_cond, parameters=parameters, initial_density=initial_density, v_bounds=v_bounds, r_bounds=r_bounds, v_steps=v_steps, r_steps=r_steps, cfl=cfl,)

# Evaluate expected affine outputs from E[V].
U_values = np.array([float(U(tk)) for tk in t])
B_O_values = np.array([float(B_O(tk)) for tk in t])
B_I_values = np.array([float(B_I(tk)) for tk in t])
PE_values = np.array([float(PE(tk)) for tk in t])
mean_v = fp["mean_v"]
mean_r = fp["mean_r"]
std_v = np.sqrt(np.maximum(fp["var_v"], 0.0))
std_r = np.sqrt(np.maximum(fp["var_r"], 0.0))

mean_O = beta[0] * B_O_values + beta[1] * mean_v + beta[2] * (1.0 - U_values)
mean_I = (alpha[0] * B_I_values+ alpha[1] * (1.0 - mean_v)+ alpha[2] * mean_O+ alpha[3] * (1.0 - U_values))
mean_A = (gamma[0] * (1.0 - U_values) + gamma[1] * mean_I+ gamma[2] * mean_v+ gamma[3] * (1.0 - PE_values))

mean_g = sigma_0 + sigma_O * mean_O

V_star = np.array([model.expected_equilibrium(bo, bi, u, alpha, beta)for bo, bi, u in zip(B_O_values, B_I_values, U_values)])

# Report parameter and numerical checks.
dV = model.reduced_drift_coefficients(B_O_level, B_I_level, alpha, beta)[1]
corner_equilibria = np.array([model.expected_equilibrium(bo, bi, u, alpha, beta) for bo, bi, u in product((0.0, 1.0), repeat=3)])

print("wm_2 Fokker-Planck single price-step example")
print("-------------------------------------------")
print(f"d_V:                              {dV:.6f}")
print(f"kappa_R:                          {kappa_R:.6f}")
print(f"Non-oscillatory threshold -4d_V: {-4.0 * dV:.6f}")
print("V* over parameter-domain corners: " f"[{np.min(corner_equilibria):.6f}, {np.max(corner_equilibria):.6f}]")
print(f"Initial V*(U={price_before:.2f}):         {V0:.6f}")
print("Initial beta-mixture V means:      " + np.array2string(v_component_means, precision=4))
print("Initial beta-mixture R means:      " + np.array2string(r_component_means, precision=4))
print(f"Post-step V*(U={price_after:.2f}):       " f"{model.expected_equilibrium(B_O_level, B_I_level, price_after, alpha, beta):.6f}")
print(f"Maximum |FP mass - 1|:            {np.max(np.abs(fp['mass'] - 1.0)):.3e}")
print("Maximum |E_FP[V]-V_deterministic|: " f"{np.max(np.abs(mean_v - deterministic['V'])):.3e}")
print(f"Minimum expected output E[O]:     {np.min(mean_O):.6f}")
print(f"Minimum diffusion scale g(E[O]): {np.min(mean_g):.6f}")

# Build state, rate, flow, and density diagnostics.
v_grid = fp["v_grid"]
mass = fp["mass"]
normalised_marginal_v = fp["marginal_v"] / mass[:, None]
heatmap_probability = normalised_marginal_v / np.max(normalised_marginal_v)

fig, axes = plt.subplots(4, 1, figsize=(11, 16), constrained_layout=True)
ax_pdf, ax_state, ax_rate, ax_flow = axes

mesh = ax_pdf.pcolormesh(hours, v_grid, heatmap_probability.T, shading="auto", vmin=0.0, vmax=1.0,)
fig.colorbar(mesh, ax=ax_pdf, label="Normalized probability density")
ax_pdf.plot(hours, mean_v, linewidth=1.8, label="E[V]")
ax_pdf.plot(hours, V_star, linestyle="--", linewidth=1.4, label="V*(B,U)")
ax_pdf.axhline(0.0, linestyle=":", linewidth=1.0)
ax_pdf.axhline(1.0, linestyle=":", linewidth=1.0)
ax_pdf.axvline(price_step_hour, linestyle="--", linewidth=1.0)
ax_pdf.set_ylabel("Flexibility state V")
ax_pdf.set_title("wm_2 Fokker-Planck marginal density of V")
ax_pdf.legend(loc="best")

ax_state.step(hours, U_values, where="post", label="Price U")
ax_state.plot(hours, deterministic["V"], linewidth=1.5, label="Deterministic V")
ax_state.plot(hours, mean_v, linewidth=2.0, label="Fokker-Planck E[V]")
ax_state.plot(hours, V_star, linestyle="--", label="Expected equilibrium V*")
ax_state.fill_between(hours, mean_v - std_v, mean_v + std_v, alpha=0.20, label="E[V] +/- std(V)",)
ax_state.axhline(0.0, linestyle=":")
ax_state.axhline(1.0, linestyle=":")
ax_state.axvline(price_step_hour, linestyle="--")
ax_state.set_ylabel("Price / flexibility")
ax_state.set_title("Single price step and inertial flexibility response")
ax_state.grid(True)
ax_state.legend(loc="best")

ax_rate.plot(hours, deterministic["R"], linewidth=1.5, label="Deterministic R")
ax_rate.plot(hours, mean_r, linewidth=2.0, label="Fokker-Planck E[R]")
ax_rate.fill_between(hours, mean_r - std_r, mean_r + std_r, alpha=0.20, label="E[R] +/- std(R)",)
ax_rate.axhline(0.0, linestyle=":")
ax_rate.axvline(price_step_hour, linestyle="--")
ax_rate.set_ylabel("Rate R")
ax_rate.set_title("wm_2 inertial-rate response")
ax_rate.grid(True)
ax_rate.legend(loc="best")

ax_flow.plot(hours, mean_O, label="E[O]")
ax_flow.plot(hours, mean_I, label="E[I]")
ax_flow.plot(hours, mean_A, label="E[A]")
ax_flow.axvline(price_step_hour, linestyle="--")
ax_flow.set_xlabel("Time [hours]")
ax_flow.set_ylabel("Normalized model output")
ax_flow.set_title("Expected affine model outputs and output-scaled diffusion")
ax_flow.grid(True)
ax_flow.legend(loc="upper left")

ax_diffusion = ax_flow.twinx()
ax_diffusion.plot(hours, mean_g, linestyle="--", label="g(E[O])")
ax_diffusion.set_ylabel("Diffusion scale")
ax_diffusion.legend(loc="upper right")

# Resolve the output directory from the repository root.
graph_dir = Path(__file__).resolve().parents[3] / "files" / "output" / "graphs"
graph_dir.mkdir(parents=True, exist_ok=True)
graph_path = graph_dir / "wm_2_fp_price_step.png"
fig.savefig(graph_path, dpi=300, bbox_inches="tight")
plt.close(fig)

print(f"Saved graph to {graph_path}")
