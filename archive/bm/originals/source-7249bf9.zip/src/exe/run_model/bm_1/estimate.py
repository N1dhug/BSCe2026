"""F4 estimation entry point.

F4-B exposes the reproducible synthetic generator; F4-C/D validate FV/mixture
state filters. F4-E screens fixed-parameter predictive likelihoods. F4-F studies
recursive one-parameter banks, numerical accuracy and prior/support sensitivity.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess
import sys
from time import perf_counter

def _configure_blas_startup(argv):
    """Opt-in process-local BLAS limits, before importing NumPy/SciPy.

    Spawned workers inherit these settings. Importing this module as a library
    never changes the environment; notebook users can use threadpoolctl instead.
    """
    probe = argparse.ArgumentParser(add_help=False)
    probe.add_argument('--blas-threads', type=int)
    requested, _ = probe.parse_known_args(argv)
    if requested.blas_threads is not None:
        if requested.blas_threads < 1:
            probe.error('--blas-threads must be positive')
        for variable in ('OPENBLAS_NUM_THREADS', 'OPENBLAS_DEFAULT_NUM_THREADS',
                         'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'BLIS_NUM_THREADS',
                         'VECLIB_MAXIMUM_THREADS'):
            os.environ[variable] = str(requested.blas_threads)


if __name__ == '__main__':
    _configure_blas_startup(sys.argv[1:])

# Numerical libraries are deliberately imported after the optional CLI limits.
import numpy as np

from src.validation.bm_1 import estimation as synthetic
from src.validation.bm_1 import mixture_estimation as mixture_validation
from src.validation.bm_1 import joint_estimation as joint_validation
from src.validation.bm_1 import joint_grid
from src.validation.bm_1 import joint_robustness
from src.validation.bm_1 import joint_diagnostics
from src.validation.bm_1 import joint_pilot
from src.validation.bm_1 import joint_night
from src.exe.run_model.progress import fv_work, runtime_text
from src.tools.checkpoint_io import discard_file
from src.tools.bm_1_reports import (
    _atomic_report, _write_array_checkpoint, _read_array_checkpoint,
    _read_likelihood_report, _RunLock,
)



ROOT = Path(__file__).resolve().parents[4]
OUTPUT_DIR = ROOT / 'files' / 'output' / 'bm_1' / 'runs' / 'estimation'


def _diagnostics_record(values):
    record = {}
    for key, value in values.items():
        if isinstance(value, np.ndarray):
            continue
        if isinstance(value, (np.integer, np.floating)):
            value = value.item()
        if isinstance(value, (str, int, float, bool)) or value is None:
            record[key] = value
    return record


def _sequence_record(result):
    return {
        'sequence_id': result.sequence_id,
        'observation_times': result.observations.times.tolist(),
        'observations': result.observations.values.tolist(),
        'truth': {
            'times': result.truth.times.tolist(),
            'state': result.truth.state.tolist(),
            'price': result.truth.price.tolist(),
            'baseline': result.truth.baseline.tolist(),
            'demand': result.truth.demand.tolist(),
            'initial_state': result.truth.initial_state,
            'valid': result.truth.valid,
            'diagnostics': _diagnostics_record(result.truth.diagnostics),
        },
        'measurement_noise': result.measurement_noise.tolist(),
    }


def _print_sequence(result, label='base'):
    diagnostics = result.truth.diagnostics
    print(f'F4-B synthetic {label}: sequence {result.sequence_id}')
    print(
        f"  X0={result.truth.initial_state:.6f}; "
        f"state range=[{np.min(result.truth.state):.6f}, {np.max(result.truth.state):.6f}]"
    )
    print(
        f"  observations={result.observations.times.size}; "
        f"EM steps={diagnostics['n_steps']}; "
        f"raw boundary violations={diagnostics['total_violations']}"
    )
    print(
        f"  first Y={result.observations.values[0]:.6f}; "
        f"last Y={result.observations.values[-1]:.6f}"
    )


def run_synthetic(args):
    suffix = 'refinement' if args.refine else 'sequence'
    path = OUTPUT_DIR / f'f4_b_{suffix}_{args.sequence_id:04d}.json'
    if args.save and path.exists():
        raise FileExistsError(f'Refusing to overwrite {path}; choose a new sequence id.')
    case = synthetic.build_f4_b_case()
    if args.refine:
        result = synthetic.generate_coupled_refinement(case, sequence_id=args.sequence_id)
        _print_sequence(result.coarse, 'coarse')
        _print_sequence(result.fine, 'fine')
        print(f'  max |X_coarse-X_fine|={result.maximum_abs_state_difference:.6e}')
        print(f'  max |D_coarse-D_fine|={result.maximum_abs_demand_difference:.6e}')
        payload = {
            'case': 'F4-A locked core',
            'refinement': {
                'coarse': _sequence_record(result.coarse),
                'fine': _sequence_record(result.fine),
                'maximum_abs_state_difference': result.maximum_abs_state_difference,
                'maximum_abs_demand_difference': result.maximum_abs_demand_difference,
            },
        }
    else:
        result = synthetic.generate_synthetic_sequence(case, sequence_id=args.sequence_id)
        _print_sequence(result)
        payload = {'case': 'F4-A locked core', 'sequence': _sequence_record(result)}
    if args.save:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        with path.open('x', encoding='utf-8') as handle:
            json.dump(payload, handle, indent=2, allow_nan=False)
            handle.write('\n')
        print(f'Saved {path}')
    return result



def run_filter(args):
    """Run one F4-C known-parameter filter sanity case."""
    result = synthetic.run_f4_c_reference(
        sequence_id=args.sequence_id,
        x_steps=args.cells,
        max_step=args.max_step,
        likelihood_quadrature_order=args.quadrature_order,
    )
    truth = result.sequence.truth.state[1:]
    open_mean = result.open_propagation.posterior_mean
    predictive = result.filtered.predicted_mean
    posterior = result.filtered.posterior_mean

    def rmse(values):
        return float(np.sqrt(np.mean(np.square(values - truth))))

    print(f'F4-C FV filter: sequence {args.sequence_id}')
    print(
        f'  cells={result.filtered.x_grid.size}; '
        f'FP steps={result.filtered.integration_t.size - 1}; '
        f'actual max step={np.max(np.diff(result.filtered.integration_t)):.6e} day'
    )
    print(
        f'  RMSE open={rmse(open_mean):.6e}; '
        f'predictive={rmse(predictive):.6e}; '
        f'posterior={rmse(posterior):.6e}'
    )
    print(
        f'  log likelihood={result.filtered.total_log_likelihood:.6f}; '
        f'max mass error={result.filtered.maximum_abs_mass_error:.3e}; '
        f'min cell mass={result.filtered.minimum_cell_mass:.3e}'
    )
    for hour in (6, 12, 24):
        index = hour - 1
        print(
            f'  t={hour:02d}h: true={truth[index]:.6f}; '
            f'open={open_mean[index]:.6f}; pred={predictive[index]:.6f}; '
            f'post={posterior[index]:.6f}'
        )
    return result


def _print_refinement_axis(title, rows):
    print(title)
    print('  level          RMSE open    RMSE pred    RMSE post    logL        steps   actual h      mass err   min mass')
    for row in rows:
        level = row['level']
        level_text = f'{level:.6g}' if isinstance(level, float) else str(level)
        print(
            f"  {level_text:<12} "
            f"{row['rmse_open']:.6e}  {row['rmse_predictive']:.6e}  "
            f"{row['rmse_posterior']:.6e}  {row['total_log_likelihood']:.6f}  "
            f"{row['n_steps']:>5d}   {row['actual_max_step']:.6e}  "
            f"{row['maximum_abs_mass_error']:.1e}  {row['minimum_cell_mass']:.1e}"
        )


def run_filter_refinement(args):
    """Run the preregistered one-at-a-time F4-C numerical refinement study."""
    result = synthetic.run_f4_c_refinement(sequence_id=args.sequence_id)
    print(f'F4-C numerical refinement: sequence {args.sequence_id}')
    _print_refinement_axis('Spatial cells', result['spatial'])
    _print_refinement_axis('FV max step [day]', result['time'])
    _print_refinement_axis('Measurement quadrature order', result['quadrature'])
    for axis in ('spatial', 'time', 'quadrature'):
        summary = result['summary'][axis]
        ratio = summary['effect_to_assimilation_ratio']
        ratio_text = 'n/a' if not np.isfinite(ratio) else f'{ratio:.4f}'
        print(
            f"  {axis}: max posterior-RMSE refinement effect="
            f"{summary['maximum_posterior_rmse_effect']:.6e}; "
            f"effect/assimilation={ratio_text}; "
            f"max |delta logL|={summary['maximum_log_likelihood_effect']:.6e}"
        )
    return result



def run_filter_study(args):
    """Run the preregistered multi-sequence F4-C state-filter study."""
    print(
        f'F4-C population study: sequences {args.start}..'
        f'{args.start + args.sequences - 1} (n={args.sequences})'
    )
    result = synthetic.run_f4_c_population(
        n_sequences=args.sequences,
        sequence_start=args.start,
        bootstrap_replicates=args.bootstrap_replicates,
    )
    rmse = result['rmse']
    score = result['predictive_log_score']
    print(
        f"  RMSE open={rmse['open']:.6e}; predictive={rmse['predictive']:.6e}; "
        f"posterior={rmse['posterior']:.6e}"
    )
    print(
        f"  RMSE-/RMSE0={rmse['predictive_over_open']:.6f} "
        f"[bootstrap95 {rmse['predictive_over_open_bootstrap95'][0]:.6f}, "
        f"{rmse['predictive_over_open_bootstrap95'][1]:.6f}]"
    )
    print(
        f"  RMSE+/RMSE0={rmse['posterior_over_open']:.6f} "
        f"[bootstrap95 {rmse['posterior_over_open_bootstrap95'][0]:.6f}, "
        f"{rmse['posterior_over_open_bootstrap95'][1]:.6f}]"
    )
    print(
        f"  predictive Y log score/obs: filter={score['filter_mean_per_observation']:.6f}; "
        f"open={score['open_mean_per_observation']:.6f}; "
        f"paired delta={score['paired_difference']:.6f} "
        f"[bootstrap95 {score['paired_difference_bootstrap95'][0]:.6f}, "
        f"{score['paired_difference_bootstrap95'][1]:.6f}]"
    )
    print(
        f"  first-observation score agreement max abs diff="
        f"{score['first_observation_max_abs_difference']:.3e}"
    )
    for hour in (6, 12, 24):
        item = result['coverage90_posterior'][hour]
        print(
            f"  posterior 90% coverage at {hour:02d}h: "
            f"{item['successes']}/{item['total']}={item['coverage']:.3f}; "
            f"Wilson95=[{item['wilson95'][0]:.3f}, {item['wilson95'][1]:.3f}]; "
            f"mean width={item['mean_width']:.6f}"
        )
    diagnostics = result['diagnostics']
    print(
        f"  invalid truth sequences={len(diagnostics['invalid_truth_sequences'])}; "
        f"open max mass error={diagnostics['open_maximum_abs_mass_error']:.3e}; "
        f"open min cell mass={diagnostics['open_minimum_cell_mass']:.3e}"
    )
    if args.sequences < 200:
        print('  diagnostic only: preregistered F4-C population study requires >=200 sequences')
    return result



def run_filter_calibration(args):
    """Run the post-hoc C4 numerical coverage sensitivity diagnostic."""
    result = synthetic.run_f4_c_calibration_sensitivity(
        n_sequences=args.sequences,
        sequence_start=args.start,
    )
    print(
        f'F4-C calibration sensitivity: sequences {args.start}..'
        f'{args.start + args.sequences - 1} (n={args.sequences})'
    )
    for name, variant in result['variants'].items():
        print(
            f"  {name}: cells={variant['x_steps']}; "
            f"hmax={variant['max_step']:.6e}; q={variant['quadrature_order']}"
        )
        for hour in (6, 12, 24):
            item = variant['horizons'][hour]
            print(
                f"    {hour:02d}h coverage={item['coverage']:.3f} "
                f"[Wilson95 {item['wilson95'][0]:.3f}, {item['wilson95'][1]:.3f}]; "
                f"width={item['mean_width']:.6f}; "
                f"RMSE={item['posterior_mean_rmse']:.6f}; "
                f"sqrt(E[var])={item['root_mean_posterior_variance']:.6f}; "
                f"RMSE/sd={item['rmse_over_posterior_sd']:.3f}"
            )
    print(f"  invalid truth sequences={len(result['invalid_truth_sequences'])}")
    return result

def run_filter_truth_refine(args):
    """Run the paired coarse/fine truth-EM calibration sensitivity diagnostic."""
    result = synthetic.run_f4_c_truth_refinement(
        n_sequences=args.sequences,
        sequence_start=args.start,
    )
    print(
        f'F4-C truth refinement: sequences {args.start}..'
        f'{args.start + args.sequences - 1} (n={args.sequences})'
    )
    for label in ('coarse', 'fine'):
        summary = result[label]
        print(
            f"  {label}: max mass error={summary['maximum_abs_mass_error']:.3e}; "
            f"min cell mass={summary['minimum_cell_mass']:.3e}"
        )
        for hour in (6, 12, 24):
            item = summary['horizons'][hour]
            print(
                f"    {hour:02d}h coverage={item['coverage']:.3f} "
                f"[Wilson95 {item['wilson95'][0]:.3f}, {item['wilson95'][1]:.3f}]; "
                f"width={item['mean_width']:.6f}; "
                f"RMSE={item['posterior_mean_rmse']:.6f}; "
                f"sqrt(E[var])={item['root_mean_posterior_variance']:.6f}; "
                f"RMSE/sd={item['rmse_over_posterior_sd']:.3f}"
            )
    diff = result['truth_difference']
    print(
        f"  coarse/fine truth differences: max |dX|={diff['maximum_abs_state']:.3e}; "
        f"RMS dX={diff['rms_state']:.3e}; max |dD|={diff['maximum_abs_demand']:.3e}; "
        f"RMS dD={diff['rms_demand']:.3e}; max |dY|={diff['maximum_abs_observation']:.3e}"
    )
    print(f"  invalid truth pairs={len(result['invalid_truth_pairs'])}")
    return result



def _print_mixture_representation_result(result, label):
    print(f"F4-D {label}: cells={result['x_steps']}")
    print(
        "  dictionary                 comp   max L1      max W1      "
        "max gap     cond(A)      fallback  eligible"
    )
    for name in result['dictionary_order']:
        item = result['results'][name]['summary']
        print(
            f"  {name:<26} {item['components']:>4d}   "
            f"{item['maximum_cell_mass_l1']:.3e}  "
            f"{item['maximum_wasserstein_1']:.3e}  "
            f"{item['maximum_optimality_gap']:.2e}  "
            f"{item['projection_matrix_condition_number']:.3e}  "
            f"{str(item['any_fallback']):>8}  {str(item['eligible']):>8}"
        )
        if item['failed_targets']:
            print(
                "    FAILED targets="
                + ", ".join(item['failed_targets'])
                + "; no clipping/repair was applied"
            )
            for target in item['failed_targets']:
                fit = result['results'][name]['fits'][target]
                print(
                    f"      {target}: {fit['failure_type']}: "
                    f"{fit['failure_message']}"
                )
        else:
            print(
                f"    worst L1={item['worst_l1_target']}; "
                f"worst W1={item['worst_w1_target']}; "
                f"condition alarm={item['conditioning_alarm']}"
            )
    selected = result['selected_dictionary']
    print(f"  selected dictionary={selected if selected is not None else 'NONE'}")
    if selected is not None:
        print("  selected per-target errors:")
        for target, fit in result['results'][selected]['fits'].items():
            print(
                f"    {target:<16} L1={fit['cell_mass_l1']:.3e}; "
                f"W1={fit['wasserstein_1']:.3e}; "
                f"L2={fit['density_l2']:.3e}; "
                f"dmean={fit['mean_error']:.3e}; "
                f"dvar={fit['variance_error']:.3e}; "
                f"active={fit['active_components']}"
            )
    return result


def run_mixture_static(args):
    """Run the original preregistered F4-D D1 representation study."""
    result = mixture_validation.run_f4_d_representation_study(x_steps=args.cells)
    return _print_mixture_representation_result(result, 'static mixture representation D1')


def run_mixture_static_adaptive(args):
    """Run the preregistered post-D1 adaptive D1b representation study."""
    result = mixture_validation.run_f4_d_adaptive_representation_study(x_steps=args.cells)
    return _print_mixture_representation_result(result, 'adaptive static representation D1b')


def run_mixture_static_shape_aware(args):
    """Run the preregistered post-D1b shape-aware D1c representation study."""
    result = mixture_validation.run_f4_d_shape_aware_representation_study(x_steps=args.cells)
    return _print_mixture_representation_result(result, 'shape-aware static representation D1c')


def run_mixture_holdout(args):
    """Run the preregistered F4-D D2 FV-snapshot holdout."""
    result = mixture_validation.run_f4_d_snapshot_holdout(
        sequence_start=args.start,
        n_sequences=args.sequences,
        x_steps=args.cells,
        max_step=args.max_step,
        likelihood_quadrature_order=args.quadrature_order,
    )
    print(
        f"F4-D D2 snapshot holdout: dictionary={result['dictionary']}; "
        f"sequences={result['sequence_ids'][0]}..{result['sequence_ids'][-1]}; "
        f"cells={result['x_steps']}"
    )
    for label in ('prediction', 'posterior'):
        item = result[label]
        print(
            f"  {label}: max L1={item['maximum_cell_mass_l1']:.6e}; "
            f"max W1={item['maximum_wasserstein_1']:.6e}; "
            f"max CDF={item['maximum_cdf_sup']:.6e}; "
            f"max L2={item['maximum_density_l2']:.6e}"
        )
        print(
            f"    max |dmean|={item['maximum_abs_mean_error']:.6e}; "
            f"max |dvar|={item['maximum_abs_variance_error']:.6e}; "
            f"max gap={item['maximum_optimality_gap']:.3e}; "
            f"max mass error={item['maximum_mass_error']:.3e}; "
            f"fallbacks={item['fallback_count']}; "
            f"passes={item['passes_representation_gate']}"
        )
        if item['failed_snapshot_indices']:
            print(
                f"    failed snapshot indices={item['failed_snapshot_indices']}"
            )
    score = result['predictive_log_evidence_error']
    print(
        f"  predictive log-evidence error: complete={score['complete']}; "
        f"count={score['count']}/{score['expected_count']}; "
        f"mean abs/obs={score['mean_absolute_per_observation']:.6e}; "
        f"max abs/obs={score['maximum_absolute_per_observation']:.6e}; "
        f"mean signed/obs={score['mean_signed_per_observation']:.6e}; "
        f"max |daily sum diff|={score['maximum_absolute_daily_sum_difference']:.6e}"
    )
    print(
        f"  cond(A)={result['projection_matrix_condition_number']:.3e}; "
        f"cond(H)={result['hessian_condition_number']:.3e}; "
        f"invalid truth sequences={len(result['invalid_truth_sequences'])}; "
        f"passes holdout={result['passes_holdout']}"
    )
    return result



def run_mixture_filter_sanity(args):
    """Run the preregistered F4-D D3a recursive mixture filter sanity."""
    result = mixture_validation.run_f4_d_recursive_sanity(
        sequence_id=args.sequence_id,
        x_steps=args.cells,
        max_step=args.max_step,
        cfl=args.cfl,
        likelihood_quadrature_order=args.quadrature_order,
    )
    print(
        f"F4-D D3a recursive mixture filter: sequence={result['sequence_id']}; "
        f"dictionary={result['dictionary']}; cells={result['x_steps']}; "
        f"cfl={result['cfl']}; max_step={result['max_step']:.6e}"
    )
    initial = result['initial_projection_error']
    print(
        f"  initial projection: L1={initial['cell_mass_l1']:.6e}; "
        f"W1={initial['wasserstein_1']:.6e}; L2={initial['density_l2']:.6e}"
    )
    for family, title in (
        ('static_best_fit', 'static best-fit FV->mixture'),
        ('dynamic_gap', 'dynamic mixture->static best-fit'),
        ('total_fv_gap', 'total mixture->FV'),
    ):
        print(f"  {title}:")
        for label in ('prediction', 'posterior'):
            item = result[family][label]
            print(
                f"    {label}: max L1={item['maximum_cell_mass_l1']:.6e}; "
                f"max W1={item['maximum_wasserstein_1']:.6e}; "
                f"max CDF={item['maximum_cdf_sup']:.6e}; "
                f"max L2={item['maximum_density_l2']:.6e}; "
                f"max |dmean|={item['maximum_abs_mean_error']:.6e}; "
                f"max |dvar|={item['maximum_abs_variance_error']:.6e}"
            )
    score = result['log_evidence_error']
    print(
        f"  log-evidence error: mean abs/obs={score['mean_absolute_per_observation']:.6e}; "
        f"max abs/obs={score['maximum_absolute_per_observation']:.6e}; "
        f"mean signed/obs={score['mean_signed_per_observation']:.6e}; "
        f"|total diff|={score['absolute_total_log_likelihood_difference']:.6e}"
    )
    rmse = result['state_rmse']
    print(
        f"  state RMSE: FV pred={rmse['fv_predictive']:.6e}; "
        f"FV post={rmse['fv_posterior']:.6e}; "
        f"mixture pred={rmse['mixture_predictive']:.6e}; "
        f"mixture post={rmse['mixture_posterior']:.6e}"
    )
    num = result['numerical']
    print(
        f"  numerics: internal steps={num['total_internal_steps']}; "
        f"h range=[{num['minimum_internal_step']:.3e}, {num['maximum_internal_step']:.3e}]; "
        f"prediction fallbacks={num['prediction_projection_fallback_count']}; "
        f"posterior fallbacks={num['posterior_projection_fallback_count']}"
    )
    print(
        f"    min raw prediction={num['maximum_raw_prediction_negativity']:.3e}; "
        f"max raw mass error={num['maximum_abs_raw_prediction_mass_error']:.3e}; "
        f"max projected mass error={num['maximum_abs_projected_prediction_mass_error']:.3e}; "
        f"max Bayes->projected posterior L1={num['maximum_bayes_to_projected_posterior_l1']:.3e}"
    )
    print(
        f"    cond(A)={num['projection_matrix_condition_number']:.3e}; "
        f"cond(H)={num['hessian_condition_number']:.3e}"
    )
    return result



def run_mixture_filter_refinement(args):
    """Run the preregistered F4-D D3b numerical refinement study."""
    result = mixture_validation.run_f4_d_recursive_refinement(
        sequence_id=args.sequence_id,
    )
    print(f"F4-D D3b recursive mixture refinement: sequence={result['sequence_id']}")
    print(
        "  axis/level          cells  req h        actual h     steps   "
        "total post L1  evidence |err|/obs  mix post RMSE  fallbacks"
    )
    for axis in ('time', 'spatial'):
        for row in result[axis]:
            level = row['level']
            level_text = f"{level:.6g}" if isinstance(level, float) else str(level)
            fallbacks = row['prediction_fallbacks'] + row['posterior_fallbacks']
            print(
                f"  {axis}/{level_text:<11} {row['x_steps']:>5d}  "
                f"{row['requested_max_step']:.3e}  {row['actual_max_step']:.3e}  "
                f"{row['internal_steps']:>5d}   {row['total_posterior_l1']:.6e}   "
                f"{row['evidence_mean_abs']:.6e}       "
                f"{row['mixture_posterior_rmse']:.6e}   {fallbacks}"
            )
        summary = result['summary'][axis]
        p = summary['posterior_l1']
        e = summary['evidence_mean_abs']
        print(
            f"  {axis} summary: posterior-L1 max effect={p['maximum_effect']:.6e}; "
            f"effect/reference={p['effect_to_reference_ratio']:.4f}; "
            f"evidence max effect={e['maximum_effect']:.6e}; "
            f"effect/reference={e['effect_to_reference_ratio']:.4f}; "
            f"passes={summary['passes_stability_gate']}"
        )
    print(
        f"  unique configurations={len(result['unique_configurations'])}; "
        f"stability ratio gate={result['stability_ratio']:.2f}"
    )
    return result



def run_mixture_filter_convergence(args):
    """Run the preregistered F4-D D3c convergence confirmation."""
    result = mixture_validation.run_f4_d_recursive_convergence(
        sequence_id=args.sequence_id,
    )
    print(f"F4-D D3c convergence confirmation: sequence={result['sequence_id']}")
    print(
        "  axis/level          cells  req h        actual h     steps   "
        "total post L1  evidence |err|/obs  mix post RMSE  fallbacks"
    )
    for axis in ('time', 'spatial'):
        for row in result[axis]:
            level = row['level']
            level_text = f"{level:.6g}" if isinstance(level, float) else str(level)
            fallbacks = row['prediction_fallbacks'] + row['posterior_fallbacks']
            print(
                f"  {axis}/{level_text:<11} {row['x_steps']:>5d}  "
                f"{row['requested_max_step']:.3e}  {row['actual_max_step']:.3e}  "
                f"{row['internal_steps']:>5d}   {row['total_posterior_l1']:.6e}   "
                f"{row['evidence_mean_abs']:.6e}       "
                f"{row['mixture_posterior_rmse']:.6e}   {fallbacks}"
            )
    t = result['summary']['time']
    for label in ('posterior_l1', 'evidence_mean_abs'):
        item = t[label]
        print(
            f"  time {label}: E0={item['extrapolated_limit']:.6e}; "
            f"pred fine={item['predicted_fine']:.6e}; "
            f"obs fine={item['observed_fine']:.6e}; "
            f"pred rel err={item['relative_prediction_error']:.4f}; "
            f"|E0|/mid={item['limit_to_middle_ratio']:.4f}; "
            f"monotone={item['monotone_decrease']}; "
            f"step-bound={item['step_limit_binding']}; "
            f"passes={item['passes']}"
        )
    sp = result['summary']['spatial']
    for label in ('posterior_l1', 'evidence_mean_abs'):
        item = sp[label]
        changes = item['successive_relative_changes']
        print(
            f"  spatial {label}: successive rel changes="
            f"({changes[0]:.4f}, {changes[1]:.4f}); "
            f"max={item['maximum_relative_change']:.4f}; "
            f"step-bound={item['step_limit_binding']}; "
            f"passes={item['passes']}"
        )
    print(
        f"  time passes={t['passes']}; spatial passes={sp['passes']}; "
        f"overall={result['summary']['passes_convergence']}; "
        f"unique configurations={len(result['unique_configurations'])}"
    )
    setting = result['summary']['population_setting']
    if setting is not None:
        print(
            f"  locked population setting: cells={setting['x_steps']}; "
            f"hmax={setting['max_step']:.6e}; cfl={setting['cfl']}; "
            f"q={setting['likelihood_quadrature_order']}"
        )
    return result



def run_mixture_filter_population(args):
    """Run the final preregistered F4-D D3d paired population study."""
    print(
        f"F4-D D3d population: sequences {args.start}.."
        f"{args.start + args.sequences - 1}; cells={args.cells}; "
        f"hmax={args.max_step:.6e}; workers={args.workers}"
    )
    if args.output is not None and args.output.exists():
        raise FileExistsError(f"Refusing to overwrite {args.output}; choose a new result path.")
    started = perf_counter()

    def progress(completed, total, row):
        if not args.quiet and (completed == 1 or completed % max(1, total // 20) == 0):
            print(f"  completed {completed}/{total}; sequence={row['sequence_id']}; "
                  f"status={row['status']}; {runtime_text(started, completed, total)}",
                  flush=True)

    result = mixture_validation.run_f4_d_recursive_population(
        n_sequences=args.sequences,
        sequence_start=args.start,
        x_steps=args.cells,
        max_step=args.max_step,
        cfl=args.cfl,
        likelihood_quadrature_order=args.quadrature_order,
        bootstrap_replicates=args.bootstrap_replicates,
        workers=args.workers,
        progress=progress,
    )
    _write_likelihood_report(args, result, started)
    if result.get('successful_sequences', 0) == 0:
        print(
            f"  no successful sequences; invalid={result['invalid_truth_sequences']}; "
            f"failed={result['failed_sequences']}"
        )
        return result
    print(
        f"  successful={result['successful_sequences']}/{args.sequences}; "
        f"invalid truth={len(result['invalid_truth_sequences'])}; "
        f"failed={len(result['failed_sequences'])}"
    )
    for label in ('predictive', 'posterior'):
        item = result['rmse'][label]
        ci = item['ratio_bootstrap95']
        dci = item['difference_bootstrap95']
        print(
            f"  {label} RMSE: FV={item['fv']:.6e}; mixture={item['mixture']:.6e}; "
            f"ratio={item['ratio']:.6f} [bootstrap95 {ci[0]:.6f}, {ci[1]:.6f}]; "
            f"diff={item['difference']:.6e} "
            f"[bootstrap95 {dci[0]:.6e}, {dci[1]:.6e}]; "
            f"equivalent={item['passes_equivalence']}"
        )
    score = result['log_evidence_difference']
    print(
        f"  log-evidence: mean abs/obs={score['mean_absolute_per_observation']:.6e} "
        f"[bootstrap95 {score['mean_absolute_bootstrap95'][0]:.6e}, "
        f"{score['mean_absolute_bootstrap95'][1]:.6e}]; "
        f"max abs/obs={score['maximum_absolute_per_observation']:.6e}"
    )
    print(
        f"    mean signed/obs={score['mean_signed_per_observation']:.6e} "
        f"[bootstrap95 {score['mean_signed_bootstrap95'][0]:.6e}, "
        f"{score['mean_signed_bootstrap95'][1]:.6e}]; "
        f"daily abs mean={score['daily_absolute_mean']:.6e}; "
        f"q95={score['daily_absolute_q95']:.6e}; "
        f"max={score['daily_absolute_maximum']:.6e}; passes={score['passes']}"
    )
    for name, item in result['distribution_gap'].items():
        print(
            f"  {name}: mean={item['mean']:.6e}; q95={item['q95']:.6e}; "
            f"max={item['maximum']:.6e}; passes={item['passes']}"
        )
    num = result['numerical']
    print(
        f"  numerics: internal steps={num['total_internal_steps']}; "
        f"prediction fallbacks={num['prediction_fallbacks']}; "
        f"posterior fallbacks={num['posterior_fallbacks']}; "
        f"max mass error={num['maximum_mass_error']:.3e}; passes={num['passes']}"
    )
    if result['failed_sequences']:
        print(f"  failed sequences={result['failed_sequences']}")
    print(f"  passes population={result['passes_population']}")
    return result



def _write_likelihood_report(args, result, started):
    """Write estimation evidence with common source metadata, never overwrite a run."""
    if args.output is None:
        return
    try:
        revision = subprocess.run(
            ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True,
            capture_output=True, check=True,
        ).stdout.strip()
        dirty = bool(subprocess.run(
            ['git', 'status', '--porcelain'], cwd=ROOT, text=True,
            capture_output=True, check=True,
        ).stdout)
    except (OSError, subprocess.SubprocessError):
        revision, dirty = None, None
    payload = {
        **result,
        'source_commit': revision,
        'working_tree_dirty': dirty,
        'elapsed_seconds': perf_counter() - started,
        'blas_threads_requested': args.blas_threads,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.suffix == '.gz':
        import gzip
        handle = gzip.open(args.output, 'xt', encoding='utf-8')
    else:
        handle = args.output.open('x', encoding='utf-8')
    with handle:
        json.dump(payload, handle, indent=2, allow_nan=False)
        handle.write('\n')
    print(f"Saved {args.output}")


def run_likelihood_refinement(args):
    """Run preregistered F4-E E1 rho-likelihood numerical refinement."""
    if args.output is not None and args.output.exists():
        raise FileExistsError(
            f"Refusing to overwrite {args.output}; choose a new result path."
        )
    print(
        f"F4-E E1 likelihood refinement: sequence={args.sequence_id}; "
        f"rho nodes={len(synthetic.F4_E_RHO_GRID)}; workers={args.workers}"
    )
    started = perf_counter()

    def progress(completed, total, key, curve):
        if not args.quiet:
            cells, hmax, order = key
            print(
                f"  completed {completed}/{total}; cells={cells}; "
                f"hmax={hmax:.6e}; q={order}; "
                f"MLE rho={curve['maximizer_rho']}; "
                f"{runtime_text(started, completed, total)}",
                flush=True,
            )

    result = synthetic.run_f4_e_likelihood_refinement(
        sequence_id=args.sequence_id,
        workers=args.workers,
        progress=progress,
    )
    for axis in ('time', 'spatial', 'quadrature'):
        print(f"  {axis}:")
        for row in result[axis]:
            if axis == 'time':
                level = f"h={row['requested_max_step']:.6e}"
            elif axis == 'spatial':
                level = f"N={row['x_steps']}"
            else:
                level = f"q={row['likelihood_quadrature_order']}"
            print(
                f"    {level}: MLE rho={row['maximizer_rho']}; "
                f"actual h={row['actual_max_step']:.6e}; "
                f"steps={row['n_steps']}; "
                f"mass err={row['maximum_abs_mass_error']:.3e}"
            )
        item = result['summary'][axis]
        print(
            f"    fine/middle: same unique MLE={item['unique_same_maximizer']}; "
            f"max |delta centered logL|={item['maximum_centered_log_likelihood_change']:.6e}; "
            f"rho window={item['comparison_rho_range']}; passes={item['passes']}"
        )
    print(
        f"  unique configurations={len(result['unique_configurations'])}; "
        f"registered={result['matches_registered_design']}; "
        f"passes E1={result['passes_numerical_refinement']}"
    )

    _write_likelihood_report(args, result, started)
    return result


def run_parameter_screening(args):
    """Run locked E2 after rechecking the supplied registered E1 artifact."""
    if args.output is not None and args.output.exists():
        raise FileExistsError(f"Refusing to overwrite {args.output}; choose a new result path.")
    e1, digest = _read_likelihood_report(args.e1_report)
    settings = synthetic.f4_e_screen_numerics_from_refinement(e1)
    print(
        f"F4-E E2 parameter screening: sequences=1212..1261; "
        f"5 parameters x 41 nodes; cells={settings['x_steps']}; "
        f"hmax={settings['max_step']:.6e}; q={settings['likelihood_quadrature_order']}; "
        f"workers={args.workers}"
    )
    started = perf_counter()

    def progress(completed, total, sequence_id, row):
        if not args.quiet:
            mles = ', '.join(f"{name}={s['grid_mle']}" for name, s in row['slices'].items())
            print(f"  completed {completed}/{total}; sequence={sequence_id}; {mles}; "
                  f"{runtime_text(started, completed, total)}", flush=True)

    result = synthetic.run_f4_e_parameter_screening(
        e1_refinement=e1, workers=args.workers, progress=progress,
    )
    result['e1_report_path'] = str(args.e1_report)
    result['e1_report_sha256'] = digest
    for name, item in result['summary'].items():
        print(
            f"  {name}: median MLE={item['unique_mle_median']}; "
            f"q05/q95={item['unique_mle_q05_q95']}; "
            f"boundary={item['boundary_mle_frequency']:.1%}; "
            f"ties={item['nonunique_mle_count']}; "
            f"median truth loss={item['median_log_likelihood_loss_at_truth']:.6f}; "
            f"median LR span={item['median_lr_span_width']:.6f}; "
            f"aggregate MLE={item['aggregate_slice']['grid_mle']}"
        )
    print(f"  mass err={result['maximum_abs_mass_error']:.3e}; "
          f"min mass={result['minimum_cell_mass']:.3e}; "
          f"registered={result['matches_registered_design']}")
    print('  LR sets are shape diagnostics; nuisance parameters held at truth. '
          'E3/E4 and parameter-specific refinement still required before F4-F.')
    _write_likelihood_report(args, result, started)
    return result


def _pair_surface_figure_paths(prefix):
    if prefix is None:
        return ()
    return tuple(prefix.parent / f"{prefix.name}_{'_'.join(pair)}.png"
                 for pair in synthetic.F4_E_PAIRS)


def _save_pair_surface_figures(result, paths):
    """Plot exact E3 matrices; color clipping changes only the display."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize

    labels = {'rho': r'$\rho$', 'Xi': r'$\Xi$', 'k': r'$k$',
              'sigma_x': r'$\sigma_X$', 'sigma_y': r'$\sigma_Y$'}
    for pair, path in zip(synthetic.F4_E_PAIRS, paths):
        items = result['pair_results']['__'.join(pair)]
        surfaces = (items['aggregate_surface'], *items['sequence_surfaces'])
        rows = (len(surfaces) + 2) // 3
        fig, axes = plt.subplots(rows, 3, figsize=(12, 3 * rows + 1),
                                 squeeze=False, constrained_layout=True)
        try:
            for index, (axis, surface) in enumerate(zip(axes.flat, surfaces)):
                a, b = np.asarray(surface['first_values']), np.asarray(surface['second_values'])
                z = np.asarray(surface['centered_log_likelihood'])
                mesh = axis.pcolormesh(a, b, z.T, shading='auto', cmap='viridis',
                                       norm=Normalize(vmin=-10, vmax=0, clip=True))
                levels = [v for v in (-10, -5, -2, -.5) if np.min(z) < v < np.max(z)]
                if levels:
                    contours = axis.contour(a, b, z.T, levels=levels, colors='white', linewidths=.65)
                    axis.clabel(contours, fontsize=7, fmt='%g')
                ta, tb = surface['truth_values']
                axis.plot(ta, tb, '*', color='red', markersize=8, clip_on=False)
                maxima = np.asarray(surface['maximizer_values'])
                axis.plot(maxima[:, 0], maxima[:, 1], 'x', color='orange', markersize=6,
                          markeredgewidth=1.4, clip_on=False)
                for name, set_scale, set_ticks, values in (
                    (pair[0], axis.set_xscale, axis.set_xticks, a),
                    (pair[1], axis.set_yscale, axis.set_yticks, b),
                ):
                    if name.startswith('sigma_'):
                        set_scale('log', base=2)
                        ticks = values[::max(1, (len(values) - 1) // 4)]
                        set_ticks(ticks, labels=[f'{v:.3g}' for v in ticks])
                axis.set_xlim(a[0], a[-1])
                axis.set_ylim(b[0], b[-1])
                axis.set_xlabel(labels[pair[0]])
                axis.set_ylabel(labels[pair[1]])
                title = f"Aggregate ({result['n_sequences']} records)" if index == 0 else \
                        f"ID {surface['sequence_id']}"
                axis.set_title(title, fontsize=10)
                axis.tick_params(labelsize=8)
            for axis in list(axes.flat)[len(surfaces):]:
                axis.set_visible(False)
            fig.colorbar(mesh, ax=list(axes.flat)[:len(surfaces)], shrink=.8,
                         label='Centered log-likelihood (display floor -10)')
            fig.suptitle(f"F4-E E3: {pair[0]} / {pair[1]}\n"
                         "Other parameters fixed at truth; star = truth; x = grid maximum\n"
                         "Contours are likelihood levels, not confidence regions", fontsize=12)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as handle:
                fig.savefig(handle, format='png', dpi=150)
        finally:
            plt.close(fig)
        print(f"Saved {path}")


def run_pair_surfaces(args):
    """Replay registered E3 from saved E2 observations, with no new draws."""
    figures = _pair_surface_figure_paths(args.figure_prefix)
    targets = ((args.output,) if args.output is not None else ()) + figures
    if len({path.resolve() for path in targets}) != len(targets):
        raise ValueError('JSON and figure paths must be distinct.')
    for path in targets:
        if path.exists():
            raise FileExistsError(f"Refusing to overwrite {path}; choose a new result path.")
    e2, digest = _read_likelihood_report(args.e2_report)
    settings = synthetic.f4_e_screening_inputs(e2)
    print(f"F4-E E3 pair surfaces: sequences=1212..1221; 3 pairs x 21x21 nodes; "
          f"cells={settings['x_steps']}; hmax={settings['max_step']:.6e}; "
          f"q={settings['likelihood_quadrature_order']}; workers={args.workers}")
    started = perf_counter()

    def progress(completed, total, key, surface):
        if not args.quiet:
            sequence_id, pair = key
            print(f"  completed {completed}/{total}; sequence={sequence_id}; pair={pair}; "
                  f"MLE={surface['grid_mle']}; {runtime_text(started, completed, total)}",
                  flush=True)

    result = synthetic.run_f4_e_pair_surfaces(e2_screening=e2, workers=args.workers, progress=progress)
    result['e2_report_path'] = str(args.e2_report)
    result['e2_report_sha256'] = digest
    result['figure_paths'] = tuple(str(path) for path in figures)
    for pair in synthetic.F4_E_PAIRS:
        item = result['pair_results']['__'.join(pair)]
        surface = item['aggregate_surface']
        print(f"  {pair}: aggregate MLE={surface['grid_mle']}; "
              f"aggregate boundary={surface['boundary_dimensions']}; "
              f"sequence boundary frequency={item['boundary_mle_frequency']}; "
              f"ties={item['nonunique_mle_count']}")
    print(f"  mass err={result['maximum_abs_mass_error']:.3e}; "
          f"min mass={result['minimum_cell_mass']:.3e}; "
          f"max E2 truth-cut difference={result['maximum_e2_truth_cut_difference']:.3e}; "
          f"registered={result['matches_registered_design']}")
    print('  Aggregate uses the same first ten E2 records. Surfaces and grid profiles are '
          'diagnostics; parameter selection remains E4.')
    if figures:
        _save_pair_surface_figures(result, figures)
    _write_likelihood_report(args, result, started)
    return result


def run_bank_identity(args):
    if args.output is not None and args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    started = perf_counter()
    print('F4-F F0 FV rho bank: sequence=1262; hypotheses=41; cells=401; '
          f'hmax={1/768:.6e}; q=3; workers={args.workers}')
    online_total = 0

    def progress(row):
        nonlocal online_total
        if row['phase'] == 'online':
            online_total = row['total']
            completed = row['completed']
        else:
            completed = 2*online_total
        if not args.quiet:
            print(f"  {row['phase']}: completed {row['completed']}/{row['total']}; "
                  f"{runtime_text(started, completed, 2*online_total)}", flush=True)

    result = synthetic.run_f4_f_bank_identity(workers=args.workers, progress=progress)
    for name, error in result['maximum_errors'].items():
        print(f'  max |delta {name}|={error:.6e}')
    print(f"  mass err={result['maximum_abs_mass_error']:.3e}; "
          f"min mass={result['minimum_cell_mass']:.3e}; "
          f"actual h={result['actual_max_step']:.6e}")
    print(f"  final rho mean={result['rho_posterior_mean'][-1]:.6g}; "
          f"MAP rho={result['map_rho'][-1]}; "
          f"effective hypotheses={result['effective_hypotheses'][-1]:.6g}; "
          f"endpoint weight={result['endpoint_weight'][-1]:.3%}")
    print(f"  registered={result['registered_design']}; passes F0={result['passes_f0']}")
    _write_likelihood_report(args, result, started)
    if not result['passes_f0']:
        raise RuntimeError('F0 bank identity/probability gates failed; report retained.')


def _read_bank_dependency(path, validator):
    report, digest = _read_likelihood_report(path)
    validator(report, require_source=True)
    return report, digest


def run_bank_study(args):
    """Staged remaining F4-F studies; source-linked reports and bounded progress."""
    if args.output is not None and args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    started = perf_counter()
    dependencies = {}
    refinement = mixture_check = population = None
    if args.study != 'refine':
        refinement, digest = _read_bank_dependency(args.refinement_report, synthetic.f4_f_validated_refinement)
        dependencies['refinement'] = dict(path=str(args.refinement_report), sha256=digest,
                                          source_commit=refinement['source_commit'])
    if args.study in ('population', 'population-time-refine'):
        mixture_check, digest = _read_bank_dependency(args.mixture_report, synthetic.f4_f_validated_mixture_check)
        dependencies['mixture'] = dict(path=str(args.mixture_report), sha256=digest,
                                       source_commit=mixture_check['source_commit'])
    if args.study == 'population-time-refine':
        population, digest = _read_bank_dependency(args.population_report, synthetic.f4_f_validated_population)
        for key in ('refinement', 'mixture'):
            declared = population.get('dependencies', {}).get(key, {})
            if (declared.get('sha256') != dependencies[key]['sha256']
                    or declared.get('source_commit') != dependencies[key]['source_commit']):
                raise ValueError(f'F4 population {key} dependency differs from the supplied report.')
        dependencies['population'] = dict(path=str(args.population_report), sha256=digest,
                                          source_commit=population['source_commit'])
    label = ('rho-mixture, sigma_x and sigma_y known' if args.study == 'mixture-check'
             else 'rho and sigma_x separately, sigma_y known')
    if args.study == 'population-time-refine':
        label = 'rho FV time refinement; saved mixture and sigma_x banks reused'
    print(f'F4-F bank-{args.study}: workers={args.workers}; {label}', flush=True)
    last_printed = started

    def progress(row):
        nonlocal last_printed
        now = perf_counter()
        if not args.quiet and (row['completed'] in (1, row['total']) or now-last_printed >= 10.):
            last_printed = now
            measured = row['completed'] if row['completed'] >= args.workers else 0
            print(f"  candidates {row['completed']}/{row['total']}; ID{row['sequence_id']}; "
                  f"{row['coordinate']}; {row['label']}; "
                  f"{runtime_text(started, measured, row['total'], now=now)}", flush=True)

    if args.study == 'refine':
        result = synthetic.run_f4_f_bank_refinement(workers=args.workers, progress=progress)
    elif args.study == 'sensitivity':
        result = synthetic.run_f4_f_bank_sensitivity(refinement, workers=args.workers, progress=progress)
    elif args.study == 'mixture-check':
        result = synthetic.run_f4_f_bank_mixture_check(
            refinement, workers=args.workers, progress=progress, spatial_refine=args.spatial_refine)
    elif args.study == 'population-time-refine':
        result = synthetic.run_f4_f_population_time_refinement(
            refinement, mixture_check, population, workers=args.workers, progress=progress)
    else:
        result = synthetic.run_f4_f_bank_population(refinement, mixture_check, workers=args.workers, progress=progress)
    result['dependencies'] = dependencies
    print(f"  stage={result['stage']}; banks={len(result['rows'])}; registered={result['registered_design']}; "
          f"passes={result['passes']}")
    for row in result.get('comparisons', []):
        state_error = (f"; state L1 pred/post={row['predicted_maximum_l1']:.4g}/"
                       f"{row['posterior_maximum_l1']:.4g}; limit={result['criteria']['maximum_state_l1']:g}"
                       if 'predicted_maximum_l1' in row else '')
        step_error = (f"; actual h={row['actual_max_step_left']:.6g}/{row['actual_max_step_right']:.6g}"
                      if 'actual_max_step_left' in row else '')
        print(f"  {row['coordinate']} ID{row['sequence_id']} {row.get('axis', row.get('comparison', 'paired'))}: "
              f"log-odds={row['maximum_log_odds_error']:.4g}; TV={row['maximum_weight_tv']:.4g}; "
              f"evidence={row['maximum_cumulative_evidence_error']:.4g}; passes={row['passes']}; "
              f"selected={row.get('selected', True)}{state_error}{step_error}")
    _write_likelihood_report(args, result, started)
    if not result['passes']:
        raise RuntimeError('F4-F study gates failed; report retained for review before adapting the next experiment.')


def run_joint_bank_identity(args):
    """G0 joint-bank method check; scientific design is fixed by the runner."""
    if args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    started = last_printed = perf_counter()
    print(f'F4-G G0: joint rho/Xi and sigma_x/sigma_y; workers={args.workers}', flush=True)

    def progress(row):
        nonlocal last_printed
        now = perf_counter()
        if not args.quiet and (row['completed'] in (1, row['total']) or now-last_printed >= 10):
            last_printed = now
            print(f"  conditional runs {row['completed']}/{row['total']}; {row['phase']}; "
                  f"ID{row['sequence_id']} {'/'.join(row['pair'])}; "
                  f"{runtime_text(started, row['completed'], row['total'], now=now)}", flush=True)

    result = synthetic.run_f4_g_joint_identity(workers=args.workers, progress=progress)
    for row in result['rows']:
        print(f"  {'/'.join(row['coordinates'])} ID{row['sequence_id']}: "
              f"H={len(row['hypotheses'])}; max identity error={max(row['maximum_errors'].values()):.3e}; "
              f"mass error={row['maximum_abs_mass_error']:.3e}; passes={row['passes']}")
        print(f"    final means={row['parameter_mean'][-1]}; "
              f"SD={row['parameter_sd'][-1]}; effective H={row['effective_hypotheses'][-1]:.4g}")
    print(f"  registered={result['registered_design']}; passes G0={result['passes']}")
    _write_likelihood_report(args, result, started)
    if not result['passes']:
        raise RuntimeError('G0 joint-bank identity/probability gates failed; report retained for review.')


def run_joint_bank_refinement(args):
    """G1a numerical refinement, dependent on source-linked passing G0 raw data."""
    if args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    dependency,digest = _read_bank_dependency(args.g0_report,joint_validation.validated_g0)
    started = last_printed = perf_counter()
    print(f'F4-G G1a: fixed 25-node joint measures; 42 banks / 1050 replays; workers={args.workers}',flush=True)

    def progress(row):
        nonlocal last_printed
        now = perf_counter()
        if not args.quiet and (row['completed'] in (1,row['total']) or now-last_printed>=10):
            last_printed = now
            print(f"  replays {row['completed']}/{row['total']}; ID{row['sequence_id']} "
                  f"{'/'.join(row['pair'])}; {row['label']}; "
                  f"{runtime_text(started, row['completed'], row['total'], now=now)}",flush=True)

    result = joint_validation.run_joint_bank_refinement(workers=args.workers,progress=progress)
    result['dependencies'] = dict(g0=dict(sha256=digest,source_commit=dependency['source_commit']))
    for row in result['comparisons']:
        step = '' if row['axis']!='time' else f"; actual step refined={row['actual_step_refined']}"
        print(f"  {'/'.join(row['coordinates'])} ID{row['sequence_id']} {row['axis']} "
              f"{row['left']}->{row['right']}: odds={row['maximum_log_odds_error']:.4g}; "
              f"TV={row['maximum_weight_tv']:.4g}; evidence={row['maximum_cumulative_evidence_error']:.4g}; "
              f"state L1 pred/post={row['maximum_predicted_l1']:.4g}/{row['maximum_posterior_l1']:.4g}; "
              f"passes={row['passes']}; selected={row['selected']}{step}")
    print(f"  registered={result['registered_design']}; passes G1a={result['passes']}")
    _write_likelihood_report(args,result,started)
    if not result['passes']:
        raise RuntimeError('G1a joint-bank numerical/probability gates failed; report retained for review.')


def run_joint_parameter_grid(args):
    """G1b0 grid/prior pilot, with a raw-validated clean G1a dependency."""
    return _run_joint_parameter_study(args,refinement=False)


def run_joint_parameter_grid_refinement(args):
    """G1b1 paired grid refinement, preserving the rejected G1b0 dependency."""
    return _run_joint_parameter_study(args,refinement=True)


def run_joint_parameter_grid_fine(args):
    """G1b2: consolidated 17x17-to-33x33 refinement from the reviewed G1b0."""
    return _run_joint_parameter_study(args,refinement=True,fine=True)


def run_joint_parameter_grid_dense(args):
    """G1b3: consolidated 33x33-to-65x65 refinement from reviewed G1b0."""
    return _run_joint_parameter_study(args,refinement=True,dense=True)


def _run_joint_parameter_study(args, *, refinement, fine=False, dense=False):
    if args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    started = last_printed = perf_counter()
    stage = 'G1b3' if dense else ('G1b2' if fine else ('G1b1' if refinement else 'G1b0'))
    if fine or dense:
        dependency,digest = _read_bank_dependency(args.g1b0_report,joint_grid.validated_g1b0)
        provenance = dict(sha256=digest,source_commit=dependency['source_commit'],
                          g1a=dict(dependency['dependencies']['g1a']))
        runner = joint_grid.run_joint_parameter_grid_dense if dense else joint_grid.run_joint_parameter_grid_fine
        design = ('5/9/17/33/65 nodes per axis; 33800 replays / 40 reductions; LAPACK + streaming' if dense
                  else '5/9/17/33 nodes per axis; 8712 replays / 32 reductions; LAPACK + streaming')
    elif refinement:
        dependency,digest = _read_bank_dependency(args.g1b0_report,joint_grid.validated_g1b0)
        provenance = dict(sha256=digest,source_commit=dependency['source_commit'],
                          g1a=dict(dependency['dependencies']['g1a']))
        runner = joint_grid.run_joint_parameter_grid_refinement
        design = '5/9/17 nodes per axis; 2312 fresh replays / 24 reductions'
    else:
        dependency,digest = _read_bank_dependency(args.g1a_report,joint_grid.validated_g1a)
        provenance = dict(sha256=digest,source_commit=dependency['source_commit'],
                          g0=dict(dependency['dependencies']['g0']))
        del dependency
        runner = joint_grid.run_joint_parameter_grid
        design = '3/5/9 nodes per axis; 648 fresh replays / 26 reductions'
    print(f'F4-G {stage}: {design}; workers={args.workers}',flush=True)

    def progress(row):
        nonlocal last_printed
        now = perf_counter()
        if not args.quiet and (row['completed'] in (1,row['total']) or now-last_printed>=10):
            last_printed = now
            print(f"  replays {row['completed']}/{row['total']}; ID{row['sequence_id']} "
                  f"{'/'.join(row['pair'])}; {row['label']}; "
                  f"{runtime_text(started, row['completed'], row['total'], now=now)}",flush=True)

    result = runner(workers=args.workers,progress=progress)
    result['dependencies'] = {('g1b0' if refinement else 'g1a'):provenance}
    if refinement:
        try:
            replay = joint_grid.compare_grid_overlap(dependency,result)
        except (ValueError,KeyError,TypeError) as exc:
            # Keep expensive completed replays even if final structural validation fails.
            replay = dict(tolerance=1e-10,bank_comparisons=0,maximum_errors={},
                          passes=False,validation_error=str(exc))
        result['replay_reproduction'] = replay
        result['passes'] = bool(result['passes'] and replay['passes'])
        maximum = max(replay['maximum_errors'].values(),default=None)
        error_text = f'{maximum:.3e}' if maximum is not None else 'not evaluated'
        print(f"  shared replay banks={replay['bank_comparisons']}; "
              f"maximum error={error_text}; passes={replay['passes']}")
        if 'validation_error' in replay:
            print(f"  replay validation error: {replay['validation_error']}")
        del dependency
    for row in result['comparisons']:
        if row['kind'].startswith('FV_'):
            detail = f"odds={row['maximum_log_odds_error']:.4g}; TV={row['maximum_weight_tv']:.4g}"
        else:
            detail = (f"parameter TV={row['maximum_parameter_tv']:.4g}; "
                      f"unit mean/SD={row['maximum_unit_mean_error']:.4g}/{row['maximum_unit_sd_error']:.4g}")
        print(f"  {'/'.join(row['coordinates'])} ID{row['sequence_id']} {row['kind']} "
              f"{row['left']}->{row['right']}: {detail}; "
              f"evidence={row['maximum_cumulative_evidence_error']:.4g}; "
              f"state L1 pred/post={row['maximum_predicted_l1']:.4g}/{row['maximum_posterior_l1']:.4g}; "
              f"passes={row['passes']}; selected={row['selected']}")
    print(f"  registered={result['registered_design']}; passes {stage}={result['passes']}")
    _write_likelihood_report(args,result,started)
    if not result['passes']:
        raise RuntimeError(f'{stage} grid/numerical/probability/replay gates failed; report retained for review.'
                           if refinement else 'G1b0 grid/numerical/probability gates failed; report retained for review.')



def _read_joint_grid_inputs(args):
    """Exact G1b3/G1b0 chain and shared replay check, without new fits."""
    previous,previous_digest = _read_bank_dependency(args.g1b0_report,joint_grid.validated_g1b0)
    report,digest = _read_likelihood_report(args.grid_report)
    dependency = report.get('dependencies',{}).get('g1b0',{})
    if (dependency.get('sha256')!=previous_digest or dependency.get('source_commit')!=previous['source_commit']
            or dependency.get('g1a')!=previous['dependencies']['g1a']):
        raise ValueError('G1c0 requires the exact G1b0 dependency used by G1b3.')
    replay = joint_grid.compare_grid_overlap(previous,report)
    joint_grid._validate_recorded_reproduction(replay)
    recorded = report['replay_reproduction']['maximum_errors']
    for field,value in replay['maximum_errors'].items():
        joint_grid.fv._equal_array(recorded[field],value,'G1c0 reproduction '+field,1e-12)
    return report,digest,dependency,replay


def run_joint_parameter_reconstruction(args):
    """Audit saved G1b3 and reconstruct the separate G1c0 continuous law."""
    if args.output.exists(): raise FileExistsError(f'Refusing to overwrite {args.output}.')
    started = perf_counter()
    report,digest,dependency,replay = _read_joint_grid_inputs(args)
    result = joint_grid.run_joint_parameter_reconstruction(report,require_source=True)
    result['replay_reproduction'] = replay
    result['dependencies'] = dict(g1b3=dict(sha256=digest,source_commit=report['source_commit'],g1b0=dependency))
    print('F4-G G1c0: continuous tensor-hat reconstruction; no new replays; original G1b gates retained')
    for c in result['comparisons']:
        print(f"  {'/'.join(c['coordinates'])} {c['left']}->{c['right']}: "
              f"TV={c['maximum_parameter_tv']:.6g}; quadrature={c['maximum_tv_quadrature_refinement']:.3e}; "
              f"passes={c['passes']}; selected={c['selected']}")
    print(f"  original dual-cell passes={result['original_dual_cell_passes']}; G1c0 pilot passes={result['passes']}")
    _write_likelihood_report(args,result,started)
    if not result['passes']: raise RuntimeError('G1c0 reconstruction gates failed; report retained for review.')


def run_joint_continued_pilot(args):
    """G2a: validated hat dependency, new continued records, complete raw output."""
    if args.output.exists(): raise FileExistsError(f'Refusing to overwrite {args.output}.')
    started = last_printed = perf_counter()
    dense,digest,original,replay = _read_joint_grid_inputs(args)
    hat,hat_digest = _read_likelihood_report(args.hat_report)
    expected = dict(sha256=digest,source_commit=dense['source_commit'],g1b0=original)
    if hat.get('dependencies',{}).get('g1b3')!=expected:
        raise ValueError('G2a requires the exact G1b3/G1b0 files used by G1c0.')
    joint_grid.validated_g1c0(hat,dense,require_source=True)
    joint_grid._check_recorded(hat.get('replay_reproduction'),replay,'G2a G1c0 reproduction')
    dependency = dict(sha256=hat_digest,source_commit=hat['source_commit'],g1b3=expected)
    del dense,hat
    print(f'F4-G G2a: {args.days} continued days; new ID1358/1359; 33800 replays / 16 banks; '
          f'33/65 hats and all FV controls; workers={args.workers}',flush=True)
    def progress(row):
        nonlocal last_printed
        now = perf_counter()
        if not args.quiet and (row['completed'] in (1,row['total']) or now-last_printed>=10):
            last_printed = now
            print(f"  replays {row['completed']}/{row['total']}; ID{row['sequence_id']} "
                  f"{'/'.join(row['pair'])}; {row['label']}; "
                  f"{runtime_text(started, row['completed'], row['total'], now=now)}",flush=True)
    result = joint_grid.run_joint_continued_pilot(record_days=args.days,workers=args.workers,progress=progress,
                                                 backend=args.fv_backend)
    result['dependencies'] = dict(g1c0=dependency)
    # Final format/algebra errors must also preserve expensive completed replays.
    try:
        joint_grid.validated_g2a(result)
        result['raw_validation'] = dict(passes=True)
    except (ValueError,KeyError,TypeError) as exc:
        result['raw_validation'] = dict(passes=False,error=str(exc))
        result['passes'] = False
    for r in result['truth_records']:
        print(f"  ID{r['sequence_id']} truth RMS/max over sigma_y="
              f"{r['rms_demand_over_sigma_y']:.4g}/{r['maximum_abs_demand_over_sigma_y']:.4g}; passes={r['passes']}")
    for c in result['comparisons']:
        value = c['maximum_parameter_tv'] if c['kind']=='parameter_hat' else c['maximum_weight_tv']
        print(f"  ID{c['sequence_id']} {c['kind']} {c['left']}->{c['right']}: TV={value:.6g}; passes={c['passes']}")
    print(f"  completed={result['completed']}; truth={result['truth_passes']}; passes G2a={result['passes']}")
    _write_likelihood_report(args,result,started)
    if not result['passes']:
        raise RuntimeError('G2a truth/numerical/raw gates failed; complete available report retained for review.')


def run_preparation(args):
    """Reproduce independent F4-0 quadrature through the common entry point."""
    if args.output is not None and args.output.exists():
        raise FileExistsError(f"Refusing to overwrite {args.output}.")
    report = synthetic.run_f4_preparation_checks()
    text = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open('x', encoding='utf-8') as handle:
            handle.write(text + '\n')
    print(text)
    return report


def run_fv_benchmark(args):
    if args.output is not None and args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    started = perf_counter()
    def progress(done, total):
        if not args.quiet:
            print(f'  paired FV checks {done}/{total}; {runtime_text(started, done, total)}', flush=True)
    result = joint_validation.benchmark_joint_fv(record_days=args.days, repeats=args.repeats, progress=progress)
    _write_likelihood_report(args, result, started)
    print(f"FV backend comparison passes={result['passes']}; serial speedup={result['measured_serial_speedup']:.2f}x")
    if not result['passes']:
        raise RuntimeError('FV backend equivalence failed; inspect saved report.')
    return result


def run_fv_batch_benchmark(args):
    """Measure the opt-in sigma_y batch without changing any registered study."""
    if args.output is not None and args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    source = _source_snapshot()
    if source['working_tree_dirty']:
        raise ValueError('Commit source changes before the batch benchmark.')
    started = perf_counter()
    def progress(done, total):
        if not args.quiet:
            print(f'  sigma_y batch checks {done}/{total}; {runtime_text(started, done, total)}', flush=True)
    result = joint_validation.benchmark_sigma_y_batch(record_days=args.days, repeats=args.repeats,
                                                      batch_size=args.batch_size, progress=progress)
    if _source_snapshot() != source:
        raise RuntimeError('Source changed during benchmark.')
    _write_likelihood_report(args, result, started)
    print(f"Sigma_y batching passes={result['passes']}; serial speedup={result['measured_serial_speedup']:.2f}x")
    if not result['passes']:
        raise RuntimeError('Batch equivalence failed; inspect the saved report.')
    return result


def run_execution_benchmark(args):
    if args.output is not None and args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    started = perf_counter()
    completed = 0
    def progress(row):
        nonlocal completed
        completed += 1
        if not args.quiet:
            print(f"  repeat={row['repeat']}; {row['parallelism']}: {row['seconds']:.2f}s; "
                  f"{runtime_text(started, completed, 2*args.repeats)}",flush=True)
    result = joint_robustness.benchmark_execution(workers=args.workers,repeats=args.repeats,progress=progress)
    _write_likelihood_report(args,result,started)
    print(f"Execution diagnostic speedup={result['speedup']:.2f}x; no population/forecast acceptance.")
    return result


def run_joint_grid_diagnosis(args):
    """Diagnose an existing complete G2a v1; never grant production acceptance."""
    if args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    source = _source_snapshot()
    if source['working_tree_dirty']:
        raise ValueError('Grid diagnosis requires a clean source checkout.')
    started = perf_counter()
    report, digest = _read_bank_dependency(args.g2a_report, joint_grid.validated_g2a)
    if report['record_days'] != 7:
        raise ValueError('Grid diagnosis requires the complete seven-day G2a report.')
    print('G2a posthoc axis diagnosis: existing scores; no parameter-bank acceptance.', flush=True)
    axes = joint_diagnostics.diagnose_parameter_axes(report)
    panel = joint_diagnostics.select_spatial_panel(report)
    def progress(done, total):
        if not args.quiet:
            print(f'  spatial replays {done}/{total}; {runtime_text(started, done, total)}', flush=True)
    spatial = joint_diagnostics.run_spatial_panel(report, panel, rho_levels=args.rho_levels, progress=progress)
    if _source_snapshot() != source:
        raise ValueError('Source changed during grid diagnosis.')
    result = dict(stage='G2a-grid-diagnosis', registered_design=False, certifies_g2a=False,
        completed=True, sequence_ids=list(joint_grid.G2A_IDS), record_days=7,
        input_g2a=dict(sha256=digest, source_commit=report['source_commit'], passes=report['passes']),
        axis_diagnosis=axes, spatial_panel=panel, spatial_diagnosis=spatial,
        rho_spatial_levels=args.rho_levels,
        conditional_runs=spatial['conditional_runs'],
        interpretation='Posthoc diagnosis on old records. Axis comparisons use saved conditional scores; state-mixture convergence is not inferred. Spatial checks use a selected conditional subset, not a complete bank. No new G2 acceptance.')
    _write_likelihood_report(args, result, started)
    print(f"Grid diagnosis complete: {result['conditional_runs']} replays; G2a certification=False", flush=True)
    return result


def _source_snapshot():
    """Capture source before a resumable job, and verify it again before saving."""
    revision = subprocess.run(['git','rev-parse','HEAD'], cwd=ROOT, text=True, capture_output=True, check=True).stdout.strip()
    dirty = subprocess.run(['git','status','--porcelain'], cwd=ROOT, text=True, capture_output=True, check=True).stdout
    return dict(source_commit=revision, working_tree_dirty=bool(dirty))


def _development_source_snapshot():
    """Include source hashes for short I/H development reports, even when dirty."""
    snapshot = _source_snapshot()
    snapshot['source_sha256'] = {
        path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted((ROOT / 'src').rglob('*.py'))}
    return snapshot


def _collect_robustness(directory, manifest, *, require_complete=False):
    """Read every present registered unit and independently rebuild its summary."""
    stage = manifest['stage']
    joint_grid._check_recorded(manifest['design'], joint_robustness.design_header(stage), stage+' manifest design')
    source = manifest['source']
    if source.get('working_tree_dirty') is not False or not re.fullmatch('[0-9a-f]{40}', str(source.get('source_commit'))):
        raise ValueError('Resumable evidence requires a clean source commit.')
    units = joint_robustness.design_units(stage)
    expected_files = {joint_robustness.unit_name(u)+'.npz' for u in units}
    unknown = {p.name for p in (directory/'units').glob('*.npz')} - expected_files
    if unknown: raise ValueError('Unregistered unit files in run directory: '+str(sorted(unknown)))
    records, digests, truth_cache = [], {}, {}
    for unit in units:
        path = directory/'units'/(joint_robustness.unit_name(unit)+'.npz')
        if not path.exists(): continue
        report, digest = _read_likelihood_report(path)
        for key, value in source.items():
            joint_grid._check_recorded(report.get(key), value, stage+' unit source '+key)
        joint_grid._check_recorded(report.get('dependencies'), manifest['dependencies'], stage+' unit dependency')
        joint_robustness.validate_unit(report, stage, unit, require_source=True, truth_cache=truth_cache)
        if report.get('raw_validation') != {'passes':True}:
            raise ValueError('A retained unit failed final raw validation; inspect it before continuing.')
        records.append(joint_robustness.compact_unit(report)); digests[report['unit_name']] = digest
        del report
    summary = joint_robustness.summarize_units(stage, records)
    summary.update(unit_sha256=digests, source=source, dependencies=manifest['dependencies'])
    if require_complete and not summary['passes']:
        raise ValueError('G2c requires all ten complete passing G2b units; partial/failed pilots are insufficient.')
    return records, summary


def run_joint_robustness(args):
    """Gated resumable G2b/G2c with immutable raw units and derived summaries."""
    from src.validation import estimation as checks
    workers = checks.positive_integer(args.workers, 'workers')
    parallelism = args.parallelism
    limit = None if args.limit_units is None else checks.positive_integer(args.limit_units, 'limit_units')
    source = _source_snapshot()
    if not args.collect_only and source['working_tree_dirty']:
        raise ValueError('Commit source changes before starting or resuming registered evidence.')
    g2a, digest = _read_likelihood_report(args.g2a_report)
    joint_robustness.require_g2a(g2a)
    dependencies = dict(g2a=dict(sha256=digest, source_commit=g2a['source_commit'], dependencies=g2a['dependencies']))
    del g2a
    if args.study_stage=='G2c':
        pilot, pilot_digest = _read_likelihood_report(args.pilot_dir/'manifest.json')
        if pilot['stage']!='G2b' or pilot['dependencies']!=dependencies:
            raise ValueError('G2c must use the exact G2a dependency of its G2b pilot.')
        with _RunLock(args.pilot_dir):
            _, accepted = _collect_robustness(args.pilot_dir, pilot, require_complete=True)
        dependencies = dict(g2b=dict(manifest_sha256=pilot_digest, source=pilot['source'],
                            unit_sha256=accepted['unit_sha256'], **dependencies))
    with _RunLock(args.run_dir):
        path = args.run_dir/'manifest.json'
        if path.exists():
            manifest, _ = _read_likelihood_report(path)
            if manifest['stage']!=args.study_stage or manifest['dependencies']!=dependencies:
                raise ValueError('Run directory belongs to a different stage or dependency; use a new directory.')
            if not args.collect_only and manifest['source']!=source:
                raise ValueError('Resume requires the original clean source commit recorded in manifest.json.')
        else:
            if args.collect_only: raise FileNotFoundError('No run manifest to collect.')
            manifest = dict(stage=args.study_stage, source=source, dependencies=dependencies,
                            design=joint_robustness.design_header(args.study_stage))
            _atomic_report(path, manifest)
        records, summary = _collect_robustness(args.run_dir, manifest)
        if summary['failed_units']:
            _atomic_report(args.run_dir/'summary.json', summary, replace_existing=True)
            raise RuntimeError('A completed unit failed; its data are retained and no failed records are dropped.')
        present = set(summary['unit_sha256'])
        pending = [u for u in joint_robustness.design_units(args.study_stage) if joint_robustness.unit_name(u) not in present]
        if args.collect_only: pending=[]
        if limit is not None: pending=pending[:limit]
        started=last_printed=perf_counter()
        replay_count = (joint_robustness.COUNTS[-1] if args.study_stage=='G2b'
                        else joint_robustness.COUNTS[0])**2
        costs = {joint_robustness.unit_name(unit):[fv_work(settings, joint_robustness.RECORD_DAYS,
                         24*joint_robustness.RECORD_DAYS /
                         (2 if unit[2]=='sampling_2h' else 4 if unit[2]=='sampling_4h' else 1))
                  for _, settings in joint_robustness._configurations(args.study_stage, unit[0])]
                 for unit in pending}
        planned_work = sum(sum(values)*replay_count for values in costs.values())
        completed_work = 0
        finished_units = 0
        print(f'{args.study_stage}: {len(pending)} pending units; parallelism={parallelism}; workers={workers}', flush=True)
        def progress(row):
            nonlocal last_printed
            now=perf_counter()
            if not args.quiet and (row['completed'] in (1,row['total']) or now-last_printed>=10):
                last_printed=now
                within_unit = sum(min(replay_count, max(0, row['completed']-i*replay_count))*cost
                                  for i, cost in enumerate(costs[joint_robustness.unit_name(pending[finished_units])]))
                print(f"  record={row['sequence_id']}; {row['completed']}/{row['total']} replays; "
                      f"{runtime_text(started, completed_work+within_unit, planned_work, now=now)}", flush=True)
        for unit, result, elapsed in joint_robustness.iter_units(args.study_stage, pending,
                workers=workers, parallelism=parallelism, progress=progress):
            name = joint_robustness.unit_name(unit)
            result.update(source, dependencies=dependencies, workers=workers,
                          parallelism=parallelism, hypothesis_workers_per_unit=workers if parallelism=='hypotheses' else 1,
                          blas_threads_requested=args.blas_threads, elapsed_seconds=elapsed,
                          timing_scope='unit computation; units mode excludes parent preparation, transfer and raw validation')
            try:
                joint_robustness.validate_unit(result, args.study_stage, unit, require_source=True)
                if _source_snapshot()!=source: raise ValueError('Source changed during the unit.')
                result['raw_validation'] = dict(passes=True)
            except (ValueError, KeyError, TypeError) as exc:
                result.update(passes=False, raw_validation=dict(passes=False,error=str(exc)))
            destination = args.run_dir/'units'/(name+'.npz')
            _atomic_report(destination, result)
            unit_digest = hashlib.sha256(destination.read_bytes()).hexdigest()
            records.append(joint_robustness.compact_unit(result)); summary['unit_sha256'][name]=unit_digest
            digests = summary['unit_sha256']
            summary = joint_robustness.summarize_units(args.study_stage, records)
            summary.update(unit_sha256=digests, source=source, dependencies=dependencies)
            _atomic_report(args.run_dir/'summary.json', summary, replace_existing=True)
            completed_work += sum(costs[name])*replay_count
            finished_units += 1
            measured_work = (completed_work if parallelism=='hypotheses' or
                             finished_units >= min(workers, len(pending)) else 0)
            timing = runtime_text(started, measured_work, planned_work)
            print(f"  saved {destination}; passes={result['passes']}; "
                  f"complete units={len(records)}/{len(manifest['design']['unit_names'])}; {timing}", flush=True)
            if not result['passes']:
                print('  Gate failed: stopping new dispatch; retaining submitted units as they finish.', flush=True)
            del result
        _atomic_report(args.run_dir/'summary.json', summary, replace_existing=True)
        if summary['failed_units']:
            raise RuntimeError('Truth/numerical/raw gate failed; complete available units retained for review.')
        print(f"{args.study_stage}: {summary['completed_units']}/{summary['expected_units']} units; "
              f"complete={summary['complete']}; passes={summary['passes']}")
        return summary


def _rectangular_identity(manifest, unit, study=joint_pilot):
    return dict(stage=study.STAGE, design_version=2, unit_name=study.unit_name(unit),
                source=manifest['source'], dependencies=manifest['dependencies'])


def _collect_rectangular(directory, manifest, truth_cache, study=joint_pilot):
    """Final units are immutable; summaries are always rebuilt from their raw arrays."""
    joint_grid._check_recorded(manifest['design'], study.design_header(), 'rectangular manifest design')
    source = manifest['source']
    if source.get('working_tree_dirty') is not False or not re.fullmatch('[0-9a-f]{40}', str(source.get('source_commit'))):
        raise ValueError('Rectangular evidence requires a clean recorded source commit.')
    expected = {study.unit_name(u)+'.npz' for u in study.units()}
    unknown = {p.name for p in (directory/'units').glob('*.npz')} - expected
    if unknown: raise ValueError('Unregistered rectangular unit files: '+str(sorted(unknown)))
    rows, digests = [], {}
    for unit in study.units():
        path = directory/'units'/(study.unit_name(unit)+'.npz')
        if not path.exists(): continue
        report, digest = _read_likelihood_report(path)
        for key, value in _rectangular_identity(manifest, unit, study).items():
            joint_grid._check_recorded(report.get(key), value, 'rectangular unit '+key)
        group = study.make_group(unit, truth_cache[tuple(unit[0])])
        study.validate_rows(report['rows'], group)
        if report.get('raw_validation') != {'passes':True}:
            raise ValueError('Retained rectangular unit failed raw validation; inspect it before continuing.')
        rows.extend(report['rows']); digests[report['unit_name']] = digest
    summary = study.summarize(rows)
    summary.update(source=source, dependencies=manifest['dependencies'], unit_sha256=digests,
        completed_units=len(digests), expected_units=len(expected),
        conditional_runs=sum(np.prod(study.GRIDS['__'.join(u[0])][-1]).item()
            for u in study.units() if study.unit_name(u) in digests))
    return rows, summary


def _rectangular_options(args):
    from src.validation import estimation as checks
    workers = checks.positive_integer(args.workers, 'workers')
    chunk = checks.positive_integer(args.chunk_size, 'chunk_size')
    limit = None if args.limit_chunks is None else checks.positive_integer(args.limit_chunks, 'limit_chunks')
    hours = getattr(args, 'max_hours', None)
    if hours is not None:
        hours = checks.finite_scalar(hours, 'max_hours')
        if hours <= 0: raise ValueError('max_hours must be positive.')
    return workers, chunk, limit, hours


def run_joint_rectangular_pilot(args):
    """Fixed G2a v2, with one atomic rolling reduction and eight final raw units."""
    _rectangular_options(args)
    source = _source_snapshot()
    if not args.collect_only and source['working_tree_dirty']:
        raise ValueError('Commit source changes before starting or resuming rectangular evidence.')
    previous, digest = _read_bank_dependency(args.g2a_report, joint_pilot.require_previous)
    dependencies = dict(g2a_v1=dict(sha256=digest, source_commit=previous['source_commit'],
                                    dependencies=previous['dependencies']))
    del previous
    truth_cache = {pair:joint_grid._g2a_truth_record(pair, sid, joint_pilot.DAYS)
                   for pair, sid in zip(synthetic.F4_G_PAIRS, joint_grid.G2A_IDS)}
    return _run_rectangular_blocks(args, source, dependencies, truth_cache)


def run_joint_night_pilot(args):
    """Prerequisite-gated G2b v2; the eight-hour budget pauses at saved blocks."""
    started = perf_counter()
    _rectangular_options(args)
    source = _source_snapshot()
    if not args.collect_only and source['working_tree_dirty']:
        raise ValueError('Commit source changes before starting or resuming G2b-v2 evidence.')
    if not args.quiet:
        print('G2b-v2: checking the original G2a dependency and all eight G2a-v2 raw units; no FV reruns.', flush=True)
    dependencies = _night_dependencies(args.g2a_report, args.g2a_run_dir)
    truth_cache = {pair:joint_grid._g2a_truth_record(pair, sid, joint_night.DAYS)
                   for pair, sid in zip(synthetic.F4_G_PAIRS, joint_night.PILOT_IDS)}
    return _run_rectangular_blocks(args, source, dependencies, truth_cache,
                                   study=joint_night, invocation_started=started)


def _night_dependencies(g2a_report, g2a_run_dir):
    """Revalidate the original report and all eight G2a raw units; no FV replays."""
    previous, digest = _read_bank_dependency(g2a_report, joint_pilot.require_previous)
    old_dependency = dict(g2a_v1=dict(sha256=digest, source_commit=previous['source_commit'],
                                    dependencies=previous['dependencies']))
    del previous
    old_truth = {pair:joint_grid._g2a_truth_record(pair, sid, joint_pilot.DAYS)
                 for pair, sid in zip(synthetic.F4_G_PAIRS, joint_grid.G2A_IDS)}
    with _RunLock(g2a_run_dir):
        manifest, manifest_digest = _read_likelihood_report(g2a_run_dir/'manifest.json')
        joint_grid._check_recorded(manifest['stage'], joint_pilot.STAGE, 'G2a-v2 stage')
        joint_grid._check_recorded(manifest['dependencies'], old_dependency, 'G2a-v2 dependency')
        _, accepted = _collect_rectangular(g2a_run_dir, manifest, old_truth)
        if not accepted['completed'] or not accepted['passes']:
            raise ValueError('G2b-v2 requires all eight complete, raw-validated passing G2a-v2 units.')
    dependencies = dict(g2a_v2=dict(manifest_sha256=manifest_digest,
        source_commit=manifest['source']['source_commit'], unit_sha256=accepted['unit_sha256'],
        dependencies=old_dependency))
    return dependencies


def _run_rectangular_blocks(args, source, dependencies, truth_cache, *, study=joint_pilot,
                            invocation_started=None, on_saved=None, stop_requested=None):
    """Shared ordered checkpoint runner; the study adapter fixes scientific scope."""
    from concurrent.futures import ProcessPoolExecutor
    from contextlib import nullcontext
    from multiprocessing import get_context
    workers, chunk, limit, hours = _rectangular_options(args)
    invocation_started = perf_counter() if invocation_started is None else invocation_started
    deadline = None if hours is None else invocation_started + hours*3600
    stop_reason = None
    with _RunLock(args.run_dir):
        manifest_path = args.run_dir/'manifest.json'
        if manifest_path.exists():
            manifest, _ = _read_likelihood_report(manifest_path)
            if manifest['stage'] != study.STAGE or manifest['dependencies'] != dependencies:
                raise ValueError('Run directory belongs to a different design/dependency.')
            if not args.collect_only and manifest['source'] != source:
                raise ValueError('Resume requires the original clean source commit.')
        else:
            if args.collect_only: raise FileNotFoundError('No rectangular manifest to collect.')
            manifest = dict(stage=study.STAGE, design=study.design_header(),
                            source=source, dependencies=dependencies)
            _atomic_report(manifest_path, manifest)
        rows, summary = _collect_rectangular(args.run_dir, manifest, truth_cache, study)
        if hasattr(study, 'completed_group_checks') and summary['failed_comparisons'] and not args.collect_only:
            _atomic_report(args.run_dir/'summary.json', summary, replace_existing=True)
            raise RuntimeError('Saved numerical comparisons failed; inspect them before continuing.')
        checkpoint_path = args.run_dir/'checkpoint.npz'
        checkpoint = _read_likelihood_report(checkpoint_path)[0] if checkpoint_path.exists() else None
        present = set(summary['unit_sha256'])
        pending = [u for u in study.units() if study.unit_name(u) not in present]
        if checkpoint is not None:
            unit = next((u for u in study.units() if study.unit_name(u)==checkpoint.get('unit_name')), None)
            if unit is None: raise ValueError('Checkpoint has an unregistered unit.')
            for k,v in _rectangular_identity(manifest, unit, study).items():
                joint_grid._check_recorded(checkpoint.get(k), v, 'checkpoint '+k)
            restored = study.RectangularReduction(study.make_group(unit, truth_cache[unit[0]])).restore(checkpoint['reduction'])
            if study.unit_name(unit) in present:
                # Crash after publishing a final unit but before removing its rolling checkpoint.
                if restored.seen != len(restored.group['hypotheses']):
                    raise ValueError('Final unit conflicts with an incomplete checkpoint.')
                if not args.collect_only:
                    discard_file(checkpoint_path)
                checkpoint = None
            elif not pending or unit != pending[0]:
                raise ValueError('Checkpoint does not belong to the first incomplete unit.')
            del restored
        if args.collect_only:
            summary['partial_unit'] = None if checkpoint is None else dict(
                unit_name=checkpoint['unit_name'], completed_hypotheses=checkpoint['reduction']['completed_hypotheses'])
            summary['conditional_runs'] += 0 if checkpoint is None else checkpoint['reduction']['completed_hypotheses']
            _atomic_report(args.run_dir/'summary.json', summary, replace_existing=True)
            return summary
        started = perf_counter(); blocks = 0
        work_per_replay = {study.unit_name(u):fv_work(
            dict(study.configurations(u[0]))[u[-1]], study.DAYS, len(study.make_group(u, truth_cache[u[0]])['observations'].times))
            for u in pending}
        remaining_counts = {study.unit_name(u):int(np.prod(study.GRIDS['__'.join(u[0])][-1]))
                            for u in pending}
        if checkpoint is not None:
            remaining_counts[checkpoint['unit_name']] -= checkpoint['reduction']['completed_hypotheses']
        planned_work = sum(remaining_counts[name]*cost for name,cost in work_per_replay.items())
        completed_work = 0
        initial_runs = summary['conditional_runs'] + (0 if checkpoint is None else
                       checkpoint['reduction']['completed_hypotheses'])
        new_runs = 0
        expected_runs = getattr(study, 'execution_runs', manifest['design']['expected_conditional_runs'])
        counter_label = getattr(study, 'counter_label', 'study')
        if limit is not None and not args.quiet:
            print('  ETA covers all pending study work; --limit-chunks can stop this invocation sooner.', flush=True)
        if hours is not None and not args.quiet:
            print(f'  Invocation budget={hours:g}h, including setup; pause at a saved block boundary. '
                  'ETA covers all pending study work across nights.', flush=True)
        manager = (ProcessPoolExecutor(max_workers=workers, mp_context=get_context('spawn'))
                   if workers>1 and pending else nullcontext(None))
        with manager as pool:
            for unit in pending:
                group = study.make_group(unit, truth_cache[unit[0]])
                reducer = study.RectangularReduction(group)
                if checkpoint is not None: reducer.restore(checkpoint['reduction'])
                name = study.unit_name(unit)
                payload = checkpoint
                while reducer.seen < len(group['hypotheses']):
                    if stop_requested is not None and stop_requested():
                        stop_reason = 'stop_requested'
                        break
                    if deadline is not None and perf_counter() >= deadline:
                        stop_reason = 'time_budget'
                        break
                    before = reducer.seen; block_started = last_printed = perf_counter()
                    def progress(done, total):
                        nonlocal last_printed
                        now = perf_counter()
                        if not args.quiet and now-last_printed >= 20:
                            work = completed_work+(done-before)*work_per_replay[name]
                            print(f'  {name}: {done}/{total}; '
                                  f'{counter_label} replays={initial_runs+new_runs+done-before}/{expected_runs}; '
                                  f'{runtime_text(started, work, planned_work, now=now)}', flush=True)
                            last_printed = now
                    study.advance(reducer, min(before+chunk, len(group['hypotheses'])), pool,
                                        progress, workers=workers)
                    if _source_snapshot() != source: raise ValueError('Source changed during the block; original checkpoint retained.')
                    payload = dict(_rectangular_identity(manifest, unit, study), reduction=reducer.checkpoint(),
                                   last_block=dict(hypotheses=reducer.seen-before, workers=workers,
                                                   seconds_before_storage=perf_counter()-block_started))
                    # Validate the complete rolling state before atomically replacing its predecessor.
                    study.RectangularReduction(group).restore(payload['reduction'])
                    _atomic_report(checkpoint_path, payload, replace_existing=True)
                    blocks += 1
                    new_runs += reducer.seen-before
                    completed_work += (reducer.seen-before)*work_per_replay[name]
                    print(f'{name}: saved {reducer.seen}/{len(group["hypotheses"])}; '
                          f'block={payload["last_block"]["seconds_before_storage"]:.2f}s; '
                          f'{counter_label} replays={initial_runs+new_runs}/{expected_runs}; '
                          f'{runtime_text(started, completed_work, planned_work)}', flush=True)
                    if on_saved is not None:
                        on_saved(unit, reducer.seen-before)
                    if limit is not None and blocks >= limit and reducer.seen < len(group['hypotheses']):
                        stop_reason = 'block_limit'
                        break
                checkpoint = payload if reducer.seen < len(group['hypotheses']) else None
                if reducer.seen < len(group['hypotheses']): break
                result = dict(_rectangular_identity(manifest, unit, study), rows=reducer.finish())
                try:
                    study.validate_rows(result['rows'], group)
                    result['raw_validation'] = dict(passes=True)
                except (ValueError, KeyError, TypeError) as exc:
                    result['raw_validation'] = dict(passes=False, error=str(exc))
                destination = args.run_dir/'units'/(name+'.npz')
                _atomic_report(destination, result)
                discard_file(checkpoint_path)
                if not result['raw_validation']['passes']:
                    raise RuntimeError('Completed rectangular raw unit failed; available data retained.')
                rows.extend(result['rows']); summary['unit_sha256'][name] = hashlib.sha256(destination.read_bytes()).hexdigest()
                if hasattr(study, 'completed_group_checks') and unit[-1] == 'quadrature_fine':
                    if any(not c['passes'] for c in study.completed_group_checks(rows, unit)):
                        stop_reason = 'numerical_failure'
                        break
                if limit is not None and blocks >= limit:
                    stop_reason = 'block_limit'
                    break
                if deadline is not None and perf_counter() >= deadline:
                    stop_reason = 'time_budget'
                    break
        # Reuse newly validated raw rows; no second file read or extra replay.
        digests = summary['unit_sha256']; summary = study.summarize(rows)
        summary.update(source=source, dependencies=dependencies, unit_sha256=digests,
            completed_units=len(digests), expected_units=len(study.units()),
            conditional_runs=sum(np.prod(study.GRIDS['__'.join(u[0])][-1]).item()
                for u in study.units() if study.unit_name(u) in digests),
            partial_unit=None if checkpoint is None else dict(unit_name=checkpoint['unit_name'],
                completed_hypotheses=checkpoint['reduction']['completed_hypotheses']),
            invocation_seconds=perf_counter()-started, new_blocks=blocks)
        if hours is not None:
            summary.update(max_hours=hours, budget_elapsed_seconds=perf_counter()-invocation_started,
                           stop_reason=stop_reason or ('complete' if summary['completed'] else 'paused'))
        summary['conditional_runs'] += 0 if checkpoint is None else checkpoint['reduction']['completed_hypotheses']
        _atomic_report(args.run_dir/'summary.json', summary, replace_existing=True)
        print(f'{study.STAGE}: {len(digests)}/{len(study.units())} final units; '
              f'complete={summary["completed"]}; passes={summary["passes"]}')
        if (summary['completed'] and not summary['passes']) or stop_reason == 'numerical_failure':
            raise RuntimeError('Rectangular numerical gates failed; saved raw units retained for review.')
        return summary


def run_i_baseline(args):
    from src.validation.bm_1.forecast import run_i_baseline as run
    if args.output is not None and args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    started = perf_counter()
    source = _development_source_snapshot()
    def progress(phase, completed, total, completed_work, total_work):
        print(f'I-baseline {phase}: {completed}/{total} phases; '
              + runtime_text(started, completed_work, total_work), flush=True)
    result = run(progress=None if args.quiet else progress)
    if _development_source_snapshot() != source:
        raise ValueError('Source changed during I-baseline; no result published.')
    result['source_sha256'] = source['source_sha256']
    _write_likelihood_report(args, result, started)
    print(f"I-baseline integration={result['integration_passes']}; "
          f"forecast scientific acceptance={result['forecast_scientific_acceptance']}", flush=True)
    return result


def run_curve_fit_pilot(args):
    from src.validation.bm_1.response import run_curve_fit_pilot as run
    if args.output is not None and args.output.exists():
        raise FileExistsError(f'Refusing to overwrite {args.output}.')
    source = _development_source_snapshot()
    started = perf_counter()
    def progress(completed,total):
        print(f'H shared fit (budget ETA): {completed}/{total} candidate budget; '
              + runtime_text(started,completed,total),flush=True)
    result = run(progress=None if args.quiet else progress)
    if _development_source_snapshot() != source:
        raise ValueError('Source changed during curve-fit pilot; no result published.')
    result['source_sha256'] = source['source_sha256']
    _write_likelihood_report(args,result,started)
    print('Shared curve development pilot complete; scientific acceptance=False',flush=True)
    return result


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest='command', required=True)
    from src.tools.bm_1_distributed import add_commands
    add_commands(subparsers)
    curve_fit = subparsers.add_parser('curve-fit-pilot',
        help='Pooled two/four-piece fit on old TRAIN records; no H scientific acceptance.')
    curve_fit.add_argument('--output',type=Path)
    curve_fit.add_argument('--quiet',action='store_true')
    curve_fit.set_defaults(handler=run_curve_fit_pilot)
    i_baseline = subparsers.add_parser('i-baseline',
        help='Small F-based frozen-origin forecast and F3 handoff; no population acceptance.')
    i_baseline.add_argument('--output', type=Path, help='Optional new JSON/gzip report.')
    i_baseline.add_argument('--quiet', action='store_true')
    i_baseline.set_defaults(handler=run_i_baseline)
    preparation = subparsers.add_parser(
        'preparation', help='Independent continuous F4-0 quadrature and Bayes checks.',
    )
    preparation.add_argument('--output', type=Path, help='Optional new JSON file.')
    preparation.set_defaults(handler=run_preparation)
    benchmark = subparsers.add_parser('benchmark-fv', help='Paired exact FV backend checks and serial timings on old G2a records.')
    benchmark.add_argument('--days', type=int, choices=(1, 3, 7), default=7)
    benchmark.add_argument('--repeats', type=int, default=2)
    benchmark.add_argument('--output', type=Path)
    benchmark.add_argument('--quiet', action='store_true')
    benchmark.set_defaults(handler=run_fv_benchmark)
    batch_benchmark = subparsers.add_parser('benchmark-fv-batch',
        help='Paired sigma_y multiple-RHS equivalence/timings; no study release.')
    batch_benchmark.add_argument('--days', type=int, choices=(1, 3, 7), default=7)
    batch_benchmark.add_argument('--repeats', type=int, default=2)
    batch_benchmark.add_argument('--batch-size', type=int, choices=(2, 3, 4), default=4)
    batch_benchmark.add_argument('--output', type=Path)
    batch_benchmark.add_argument('--quiet', action='store_true')
    batch_benchmark.set_defaults(handler=run_fv_batch_benchmark)
    execution = subparsers.add_parser('benchmark-execution',
        help='Compare hypothesis/unit process placement on two diagnostic seven-day banks; no study acceptance.')
    execution.add_argument('--workers',type=int,default=2)
    execution.add_argument('--repeats',type=int,default=2)
    execution.add_argument('--output',type=Path)
    execution.add_argument('--quiet',action='store_true')
    execution.set_defaults(handler=run_execution_benchmark)
    diagnosis = subparsers.add_parser('joint-bank-grid-diagnose',
        help='Posthoc axis/spatial diagnosis on a complete old seven-day G2a report.')
    diagnosis.add_argument('--g2a-report', type=Path, required=True)
    diagnosis.add_argument('--output', type=Path, required=True)
    diagnosis.add_argument('--rho-levels', type=int, choices=(3,4), default=4,
        help='Rho/Xi spatial levels; four also checks 1601 to 3201 cells. Noise uses three.')
    diagnosis.add_argument('--quiet', action='store_true')
    diagnosis.set_defaults(handler=run_joint_grid_diagnosis)
    rectangular = subparsers.add_parser('joint-bank-rectangular-pilot',
        help='Fixed G2a v2: rectangular grids with atomic block checkpoints and full FV controls.')
    rectangular.add_argument('--g2a-report', type=Path, required=True, help='Complete rejected seven-day G2a v1 report.')
    rectangular.add_argument('--run-dir', type=Path, required=True)
    rectangular.add_argument('--workers', type=int, default=8)
    rectangular.add_argument('--chunk-size', type=int, default=128, help='Checkpoint frequency only; scientific design stays fixed.')
    rectangular.add_argument('--limit-chunks', type=int, help='Stop cleanly after this many new blocks.')
    rectangular.add_argument('--collect-only', action='store_true', help='Validate saved raw units and checkpoint without new replays.')
    rectangular.add_argument('--quiet', action='store_true')
    rectangular.set_defaults(handler=run_joint_rectangular_pilot)

    night = subparsers.add_parser('joint-bank-rectangular-robustness',
        help='G2b v2: full paired robustness controls, atomic blocks and an eight-hour execution budget.')
    night.add_argument('--g2a-report', type=Path, required=True, help='Original complete rejected G2a-v1 report.')
    night.add_argument('--g2a-run-dir', type=Path, required=True, help='Complete accepted G2a-v2 raw run directory.')
    night.add_argument('--run-dir', type=Path, required=True)
    night.add_argument('--workers', type=int, default=8)
    night.add_argument('--chunk-size', type=int, default=64, help='Checkpoint frequency only; does not reduce study scope.')
    night.add_argument('--max-hours', type=float, default=8, help='Pause at a block boundary after this invocation budget.')
    night.add_argument('--limit-chunks', type=int, help='Stop after this many new blocks for a short execution pilot.')
    night.add_argument('--collect-only', action='store_true', help='Validate saved raw evidence without new FV replays.')
    night.add_argument('--quiet', action='store_true')
    night.set_defaults(handler=run_joint_night_pilot)
    for command_name, stage in (('joint-bank-robustness-pilot','G2b'), ('joint-bank-robustness-population','G2c')):
        robustness = subparsers.add_parser(command_name, help=f'{stage}: gated, resumable seven-day paired experiments.')
        robustness.add_argument('--g2a-report', type=Path, required=True)
        if stage=='G2c': robustness.add_argument('--pilot-dir', type=Path, required=True)
        robustness.add_argument('--run-dir', type=Path, required=True)
        robustness.add_argument('--workers', type=int, default=8)
        robustness.add_argument('--parallelism', choices=('units','hypotheses'),
            default='units' if stage=='G2c' else 'hypotheses',
            help='units: independent records with local ordered reduction; hypotheses: parallel replays in one record. '
                 'Workers is the total process budget; units mode reports progress at completed unit boundaries.')
        robustness.add_argument('--limit-units', type=int, help='Complete at most this many new units, then stop cleanly.')
        robustness.add_argument('--collect-only', action='store_true', help='Validate and summarize saved units without new replays.')
        robustness.add_argument('--quiet', action='store_true')
        robustness.set_defaults(handler=run_joint_robustness, study_stage=stage)
    command = subparsers.add_parser(
        'synthetic',
        help='Generate one locked F4-A synthetic truth/observation sequence.',
    )
    command.add_argument('--sequence-id', type=int, default=0)
    command.add_argument(
        '--refine',
        action='store_true',
        help='Generate the coupled 1/1152 versus 1/2304 day EM pair.',
    )
    command.add_argument(
        '--save',
        action='store_true',
        help='Write the generated sequence/refinement JSON under files/output/bm_1/runs/estimation.',
    )
    command.set_defaults(handler=run_synthetic)

    filter_command = subparsers.add_parser(
        'filter',
        help='Run the F4-C known-parameter finite-volume state filter.',
    )
    filter_command.add_argument('--sequence-id', type=int, default=0)
    filter_command.add_argument('--cells', type=int, default=201)
    filter_command.add_argument('--max-step', type=float, default=1.0 / 192.0)
    filter_command.add_argument('--quadrature-order', type=int, default=1)
    filter_command.set_defaults(handler=run_filter)

    refinement = subparsers.add_parser(
        'filter-refine',
        help='Run F4-C spatial/time/measurement-quadrature refinement on fixed synthetic data.',
    )
    refinement.add_argument('--sequence-id', type=int, default=0)
    refinement.set_defaults(handler=run_filter_refinement)

    study = subparsers.add_parser(
        'filter-study',
        help='Run the preregistered F4-C multi-sequence state-filter evaluation.',
    )
    study.add_argument('--sequences', type=int, default=200)
    study.add_argument('--start', type=int, default=1)
    study.add_argument('--bootstrap-replicates', type=int, default=5000)
    study.set_defaults(handler=run_filter_study)

    calibration = subparsers.add_parser(
        'filter-calibration',
        help='Diagnose C4 coverage sensitivity to one-at-a-time numerical refinement.',
    )
    calibration.add_argument('--sequences', type=int, default=200)
    calibration.add_argument('--start', type=int, default=1)
    calibration.set_defaults(handler=run_filter_calibration)

    truth_refine = subparsers.add_parser(
        'filter-truth-refine',
        help='Compare F4-C calibration under the coupled coarse/fine F4-B truth grids.',
    )
    truth_refine.add_argument('--sequences', type=int, default=200)
    truth_refine.add_argument('--start', type=int, default=1)
    truth_refine.set_defaults(handler=run_filter_truth_refine)

    likelihood_refinement = subparsers.add_parser(
        'likelihood-refine',
        help='Run preregistered F4-E E1 rho likelihood numerical refinement.',
    )
    likelihood_refinement.add_argument(
        '--sequence-id', type=int, default=synthetic.F4_E_NUMERICAL_SEQUENCE_ID,
    )
    likelihood_refinement.add_argument(
        '--workers', type=int, default=1,
        help='Independent numerical-configuration workers; runtime only.',
    )
    likelihood_refinement.add_argument(
        '--output', type=Path,
        help='Optional new JSON file with curves, gates, settings and source revision.',
    )
    likelihood_refinement.add_argument(
        '--quiet', action='store_true',
        help='Suppress per-configuration progress, not the final summary.',
    )
    likelihood_refinement.set_defaults(handler=run_likelihood_refinement)

    parameter_screening = subparsers.add_parser(
        'parameter-screen', help='Run locked F4-E E2 one-parameter screening on IDs 1212..1261.',
    )
    parameter_screening.add_argument(
        '--e1-report', type=Path, required=True,
        help='Passing registered E1 JSON; curves and numerical settings are rechecked.',
    )
    parameter_screening.add_argument('--workers', type=int, default=1,
                                    help='Independent sequence workers; runtime only.')
    parameter_screening.add_argument('--output', type=Path,
                                    help='Optional new JSON with every curve, sequence and source revision.')
    parameter_screening.add_argument('--quiet', action='store_true',
                                    help='Suppress per-sequence progress, not the final summary.')
    parameter_screening.set_defaults(handler=run_parameter_screening)

    pair_surfaces = subparsers.add_parser(
        'pair-surfaces', help='Run registered F4-E E3 pair surfaces on the first ten E2 records.',
    )
    pair_surfaces.add_argument('--e2-report', type=Path, required=True,
                               help='Complete registered E2 JSON; saved observations are reused.')
    pair_surfaces.add_argument('--workers', type=int, default=1,
                               help='Independent (sequence,pair) workers; runtime only.')
    pair_surfaces.add_argument('--output', type=Path,
                               help='Optional new JSON with raw surfaces, ridges and evidence.')
    pair_surfaces.add_argument('--figure-prefix', type=Path,
                               help='Optional prefix for three new PNGs with aggregate and per-record surfaces.')
    pair_surfaces.add_argument('--quiet', action='store_true',
                               help='Suppress per-surface progress, not the final summary.')
    pair_surfaces.set_defaults(handler=run_pair_surfaces)

    bank_identity = subparsers.add_parser(
        'bank-identity', help='Run registered F4-F F0 FV rho bank identities on new ID1262.',
    )
    bank_identity.add_argument('--workers', type=int, default=7,
                               help='Persistent process workers over independent hypotheses.')
    bank_identity.add_argument('--output', type=Path,
                               help='Optional new JSON with prefix identities and final conditional states.')
    bank_identity.add_argument('--quiet', action='store_true',
                               help='Suppress progress, not the final summary.')
    bank_identity.set_defaults(handler=run_bank_identity)

    for command, study, description in (
            ('bank-refine', 'refine', 'F1: independent rho/sigma_x FV bank numerical refinement.'),
            ('bank-sensitivity', 'sensitivity', 'F2: parameter grid, support and prior on new data.'),
            ('bank-mixture-check', 'mixture-check', 'F3: paired recursive mixture-bank pilot and time refinement.'),
            ('bank-population', 'population', 'F4: paired one-parameter FV/mixture population.'),
            ('bank-population-time-refine', 'population-time-refine', 'F4 follow-up: refine only the FV rho reference using saved population evidence.')):
        bank = subparsers.add_parser(command, help=description)
        bank.add_argument('--workers', type=int, default=7,
                          help='Persistent spawn-process workers over independent conditional replays.')
        bank.add_argument('--output', type=Path, required=True,
                          help='New evidence file; use .json.gz for large losslessly compressed reports.')
        bank.add_argument('--quiet', action='store_true')
        if study != 'refine':
            bank.add_argument('--refinement-report', type=Path, required=True)
        if study in ('population', 'population-time-refine'):
            bank.add_argument('--mixture-report', type=Path, required=True)
        if study == 'population-time-refine':
            bank.add_argument('--population-report', type=Path, required=True)
        if study == 'mixture-check':
            bank.add_argument('--spatial-refine', action='store_true',
                              help='F3 version 2: 401-cell mixture candidate, 801-cell control; retain original 151-cell diagnostics.')
        bank.set_defaults(handler=run_bank_study, study=study)

    joint_identity = subparsers.add_parser(
        'joint-bank-identity', help='G0: selected joint FV banks versus independent fixed-parameter replays.')
    joint_identity.add_argument('--workers', type=int, default=8,
                                help='Persistent spawn workers over independent hypotheses; no nested pool.')
    joint_identity.add_argument('--output', type=Path, required=True,
                                help='New JSON/gzip report with both pairs, all prefix scores and source revision.')
    joint_identity.add_argument('--quiet', action='store_true', help='Suppress progress, not the summary.')
    joint_identity.set_defaults(handler=run_joint_bank_identity)

    joint_refinement = subparsers.add_parser(
        'joint-bank-refine',help='G1a: refine time, FV cells and likelihood quadrature for both joint banks.')
    joint_refinement.add_argument('--g0-report',type=Path,required=True,help='Passing registered clean-source G0 JSON/gzip.')
    joint_refinement.add_argument('--workers',type=int,default=8,help='Independent spawn workers; scientific design stays fixed.')
    joint_refinement.add_argument('--output',type=Path,required=True,help='New JSON/gzip report; never overwritten.')
    joint_refinement.add_argument('--quiet',action='store_true',help='Suppress intermediate progress only.')
    joint_refinement.set_defaults(handler=run_joint_bank_refinement)

    parameter_grid = subparsers.add_parser(
        'joint-bank-grid',help='G1b0: new-record joint parameter-grid/prior pilot and fresh FV controls.')
    parameter_grid.add_argument('--g1a-report',type=Path,required=True,help='Passing registered clean-source G1a JSON/gzip.')
    parameter_grid.add_argument('--workers',type=int,default=8,help='Independent spawn workers; locked pilot design.')
    parameter_grid.add_argument('--output',type=Path,required=True,help='New JSON/gzip report; never overwritten.')
    parameter_grid.add_argument('--quiet',action='store_true',help='Suppress intermediate progress only.')
    parameter_grid.set_defaults(handler=run_joint_parameter_grid)

    parameter_grid_refinement = subparsers.add_parser(
        'joint-bank-grid-refine',help='G1b1 v2: paired 9x9-to-17x17 refinement after rejected G1b0.')
    parameter_grid_refinement.add_argument('--g1b0-report',type=Path,required=True,
        help='Complete clean-source rejected G1b0 JSON/gzip with passing FV controls.')
    parameter_grid_refinement.add_argument('--workers',type=int,default=8,help='Independent spawn workers; locked paired design.')
    parameter_grid_refinement.add_argument('--output',type=Path,required=True,help='New JSON/gzip report; original G1b0 is retained.')
    parameter_grid_refinement.add_argument('--quiet',action='store_true',help='Suppress intermediate progress only.')
    parameter_grid_refinement.set_defaults(handler=run_joint_parameter_grid_refinement)

    for command,description,handler in (
            ('joint-bank-grid-fine','G1b2 v3: consolidated 17x17-to-33x33 refinement.',run_joint_parameter_grid_fine),
            ('joint-bank-grid-dense','G1b3 v4: consolidated 33x33-to-65x65 refinement.',run_joint_parameter_grid_dense)):
        parameter_grid_fine = subparsers.add_parser(command,help=description)
        parameter_grid_fine.add_argument('--g1b0-report',type=Path,required=True,
            help='Complete clean-source rejected G1b0 JSON/gzip with passing FV controls; no intermediate reruns.')
        parameter_grid_fine.add_argument('--workers',type=int,default=8,help='Independent spawn workers; BLAS=1 recommended.')
        parameter_grid_fine.add_argument('--output',type=Path,required=True,help='New JSON/gzip report; originals are retained.')
        parameter_grid_fine.add_argument('--quiet',action='store_true',help='Suppress intermediate progress only.')
        parameter_grid_fine.set_defaults(handler=handler)

    reconstruction = subparsers.add_parser(
        'joint-bank-reconstruct',help='G1c0: separate continuous tensor-hat pilot from complete G1b3 evidence.')
    reconstruction.add_argument('--grid-report',type=Path,required=True,help='Complete clean-source G1b3 JSON/gzip, including original failures.')
    reconstruction.add_argument('--g1b0-report',type=Path,required=True,help='Exact original dependency, independently rechecked.')
    reconstruction.add_argument('--output',type=Path,required=True,help='New G1c0 JSON/gzip; never overwrite G1b evidence.')
    reconstruction.set_defaults(handler=run_joint_parameter_reconstruction)

    continued = subparsers.add_parser('joint-bank-continued-pilot',
        help='G2a: new 1/3/7-day records with 33/65 hats and all FV controls.')
    continued.add_argument('--grid-report',type=Path,required=True,help='Exact complete G1b3 JSON/gzip used by G1c0.')
    continued.add_argument('--hat-report',type=Path,required=True,help='Passing clean-source G1c0 JSON/gzip.')
    continued.add_argument('--g1b0-report',type=Path,required=True,help='Exact original G1b0 dependency.')
    continued.add_argument('--days',type=int,choices=joint_grid.G2A_DAYS,default=7,
        help='Registered horizon; seven days supplies day 1/3/7 prefixes without shorter reruns.')
    continued.add_argument('--workers',type=int,default=8,help='Spawn workers; BLAS=1 recommended.')
    continued.add_argument('--fv-backend',choices=('lapack','cached'),default='lapack',
        help='Same FV scheme; cached reuses exact operators. The original default is preserved.')
    continued.add_argument('--output',type=Path,required=True,help='New G2a JSON/gzip; existing reports are never overwritten.')
    continued.add_argument('--quiet',action='store_true',help='Suppress intermediate progress only.')
    continued.set_defaults(handler=run_joint_continued_pilot)

    mixture_static = subparsers.add_parser(
        'mixture-static',
        help='Run the F4-D preregistered static mixture representation study.',
    )
    mixture_static.add_argument('--cells', type=int, default=801)
    mixture_static.set_defaults(handler=run_mixture_static)

    mixture_static_adaptive = subparsers.add_parser(
        'mixture-static-adaptive',
        help='Run the post-D1 F4-D adaptive multiresolution representation study.',
    )
    mixture_static_adaptive.add_argument('--cells', type=int, default=801)
    mixture_static_adaptive.set_defaults(handler=run_mixture_static_adaptive)

    mixture_static_shape = subparsers.add_parser(
        'mixture-static-shape',
        help='Run the post-D1b F4-D shape-aware multiresolution representation study.',
    )
    mixture_static_shape.add_argument('--cells', type=int, default=801)
    mixture_static_shape.set_defaults(handler=run_mixture_static_shape_aware)

    mixture_holdout = subparsers.add_parser(
        'mixture-holdout',
        help='Run the preregistered F4-D D2 static holdout on FV filter snapshots.',
    )
    mixture_holdout.add_argument('--start', type=int, default=1001)
    mixture_holdout.add_argument('--sequences', type=int, default=10)
    mixture_holdout.add_argument('--cells', type=int, default=801)
    mixture_holdout.add_argument('--max-step', type=float, default=1.0 / 192.0)
    mixture_holdout.add_argument('--quadrature-order', type=int, default=1)
    mixture_holdout.set_defaults(handler=run_mixture_holdout)

    mixture_filter = subparsers.add_parser(
        'mixture-filter',
        help='Run the preregistered F4-D D3a recursive mixture-filter sanity.',
    )
    mixture_filter.add_argument('--sequence-id', type=int, default=0)
    mixture_filter.add_argument('--cells', type=int, default=101)
    mixture_filter.add_argument('--max-step', type=float, default=1.0 / 384.0)
    mixture_filter.add_argument('--cfl', type=float, default=0.4)
    mixture_filter.add_argument('--quadrature-order', type=int, default=1)
    mixture_filter.set_defaults(handler=run_mixture_filter_sanity)

    mixture_filter_refine = subparsers.add_parser(
        'mixture-filter-refine',
        help='Run the preregistered F4-D D3b time/spatial refinement study.',
    )
    mixture_filter_refine.add_argument('--sequence-id', type=int, default=0)
    mixture_filter_refine.set_defaults(handler=run_mixture_filter_refinement)

    mixture_filter_converge = subparsers.add_parser(
        'mixture-filter-converge',
        help='Run the preregistered F4-D D3c convergence confirmation.',
    )
    mixture_filter_converge.add_argument('--sequence-id', type=int, default=0)
    mixture_filter_converge.set_defaults(handler=run_mixture_filter_convergence)

    mixture_filter_population = subparsers.add_parser(
        'mixture-filter-population',
        help='Run the final preregistered F4-D D3d paired population study.',
    )
    mixture_filter_population.add_argument('--start', type=int, default=1011)
    mixture_filter_population.add_argument('--sequences', type=int, default=200)
    mixture_filter_population.add_argument('--cells', type=int, default=151)
    mixture_filter_population.add_argument('--max-step', type=float, default=1.0 / 3072.0)
    mixture_filter_population.add_argument('--cfl', type=float, default=0.4)
    mixture_filter_population.add_argument('--quadrature-order', type=int, default=1)
    mixture_filter_population.add_argument('--bootstrap-replicates', type=int, default=5000)
    mixture_filter_population.add_argument(
        '--workers', type=int, default=1,
        help='Independent process workers; changes runtime only, not the scientific design.',
    )
    mixture_filter_population.add_argument('--output', type=Path,
        help='Optional new JSON file, including every sequence and source revision.')
    mixture_filter_population.add_argument('--quiet', action='store_true',
        help='Suppress intermediate progress rows, not the final summary.')
    mixture_filter_population.set_defaults(handler=run_mixture_filter_population)
    for command_parser in subparsers.choices.values():
        command_parser.add_argument('--blas-threads', type=int,
            help='Opt-in BLAS/OpenMP thread limit per process, applied at CLI startup.')
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.handler(args)


if __name__ == '__main__':
    main()
