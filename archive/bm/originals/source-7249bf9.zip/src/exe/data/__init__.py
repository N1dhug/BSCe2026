"""Data analysis executables."""
