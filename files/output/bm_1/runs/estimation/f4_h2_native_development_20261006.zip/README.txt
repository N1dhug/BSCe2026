F4-H2 native bounded synthetic evidence. No historical measurements.
linux40: completed 24+8+8 matched units; source 29dd264.
stop_resume: one hour, STOP, resume one hour; source 5db727f.
Execution source bytes match each manifest SHA256 exactly.
No old reference was recomputed. Final runner changes only STOP/timing/accounting.
