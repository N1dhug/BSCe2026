param([double]$Seconds = 900)
$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '../..'))
$active = @(Get-CimInstance Win32_Process | Where-Object {
    ($_.Name -like 'python*.exe' -or $_.Name -eq 'py.exe') -and
    $_.CommandLine -match 'src[./\\]exe[./\\]run_model'
})
if ($active.Count -gt 0) {
    throw 'En modelkørsel er aktiv. Bevar dens checkout; kør F4-H2 efter den er stoppet.'
}
if (git status --porcelain --untracked-files=no) {
    throw 'Tracked ændringer skal gemmes før source kan fastlåses.'
}
$env:OPENBLAS_NUM_THREADS = '1'
$env:OPENBLAS_DEFAULT_NUM_THREADS = '1'
$env:OMP_NUM_THREADS = '1'
$env:MKL_NUM_THREADS = '1'
$env:NUMBA_NUM_THREADS = '1'
python -B -c "import numba, llvmlite; assert numba.__version__ == '0.62.1' and llvmlite.__version__ == '0.45.1'"
if ($LASTEXITCODE -ne 0) {
    throw 'Installér først i dette Python-miljø: python -m pip install --no-deps numba==0.62.1 llvmlite==0.45.1'
}
$directory = 'files/output/bm_1/runs/estimation/f4_h2_native_pc_20261006'
python -B -m src.exe.run_model.bm_1_h2_native --run-dir $directory --seconds $Seconds
$result = $LASTEXITCODE
if ($result -ne 0 -and $result -ne 3) {
    throw "F4-H2 native kontrol fejlede (exit $result). Bevar rapport/failure; ingen automatisk gentagelse."
}
$archive = 'files/output/bm_1/runs/estimation/f4_h2_native_pc_review_20261006.zip'
if (Test-Path $archive) { throw "Bevar eksisterende arkiv: $archive" }
Compress-Archive -Path $directory, 'files/output/bm_1/runs/estimation/f4_h2_remaining_budget.json' -DestinationPath $archive
Write-Host "Returnér $archive til råreview. Exit=$result; pause er ikke accept."
